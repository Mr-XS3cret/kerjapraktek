<?
	print_r($_POST);
	require_once("business/jenisIuran.class.php");
?>