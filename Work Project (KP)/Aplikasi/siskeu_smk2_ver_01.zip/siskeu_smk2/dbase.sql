/*
SQLyog Community Edition- MySQL GUI v8.05 
MySQL - 5.0.67-0ubuntu6 : Database - mykp_dbs
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`mykp_dbs` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mykp_dbs`;

/*Table structure for table `pub_Member` */

DROP TABLE IF EXISTS `pub_Member`;

CREATE TABLE `pub_Member` (
  `idMember` int(11) NOT NULL auto_increment,
  `namaMember` varchar(45) NOT NULL,
  `passwordMember` varchar(45) NOT NULL,
  `grupMember` int(11) NOT NULL,
  PRIMARY KEY  (`idMember`),
  KEY `grup` (`grupMember`),
  CONSTRAINT `grup` FOREIGN KEY (`grupMember`) REFERENCES `pub_grupMember` (`idGrup`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `pub_Member` */

insert  into `pub_Member`(`idMember`,`namaMember`,`passwordMember`,`grupMember`) values (1,'Adi','123',1),(2,'Aldi','234',2),(3,'Ardi','456',3);

/*Table structure for table `pub_Menu` */

DROP TABLE IF EXISTS `pub_Menu`;

CREATE TABLE `pub_Menu` (
  `idMenu` int(11) default NULL,
  `namaMenu` varchar(16) default NULL,
  `accesLevel` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `pub_Menu` */

insert  into `pub_Menu`(`idMenu`,`namaMenu`,`accesLevel`) values (1,'Input Data',1),(2,'Rekapitulasi',4),(3,'Edit',1),(0,'Search',4),(4,'Fitur',1);

/*Table structure for table `pub_Sheet` */

DROP TABLE IF EXISTS `pub_Sheet`;

CREATE TABLE `pub_Sheet` (
  `idSheet` int(11) NOT NULL auto_increment,
  `namaSheet` varchar(45) NOT NULL,
  `pageSheet` varchar(45) NOT NULL,
  `levelSheet` int(11) NOT NULL,
  `idMenu` int(11) default NULL,
  PRIMARY KEY  (`idSheet`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `pub_Sheet` */

insert  into `pub_Sheet`(`idSheet`,`namaSheet`,`pageSheet`,`levelSheet`,`idMenu`) values (1,'Iuran Siswa','input',1,1),(2,'Rekap Iuran Siswa','rekap-iuran',4,2),(3,'Pemasukan Lain','input-lain',1,1),(4,'Rekap&nbsp;Pemasukan','rekap-lain',4,2),(5,'Penyetoran','setoran',1,1),(6,'Rekap&nbsp;Peminjaman','rekap-bon',1,2),(7,'Peminjaman','input-bon',1,1),(8,'Rekap Pengeluaran','rekap-out',4,2),(9,'Pengeluaran Lain','outcome',2,1),(11,'Rekap Umum Harian','lapor',4,2),(12,'Edit & Tambah Data','edit',1,3),(13,'Detail Siswa','search',4,0),(14,'Fitur Tambahan','feature',1,4);

/*Table structure for table `pub_SubSheet` */

DROP TABLE IF EXISTS `pub_SubSheet`;

CREATE TABLE `pub_SubSheet` (
  `idSubSheet` int(11) NOT NULL auto_increment,
  `namaSubSheet` varchar(45) NOT NULL,
  `idSheet` int(11) NOT NULL,
  `levelSubSheet` int(11) NOT NULL,
  PRIMARY KEY  (`idSubSheet`),
  KEY `parentSheet` (`idSheet`),
  CONSTRAINT `parentSheet` FOREIGN KEY (`idSheet`) REFERENCES `pub_Sheet` (`idSheet`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `pub_SubSheet` */

insert  into `pub_SubSheet`(`idSubSheet`,`namaSubSheet`,`idSheet`,`levelSubSheet`) values (1,'Rekap Komite',2,2),(2,'Rekap TA',2,2),(3,'Rekap OSIS',2,2),(4,'Rekap Prakerin',2,2),(5,'Rekap DPS',2,2),(6,'Rekap Harian',2,2),(7,'Pemasukan Tetap',4,4),(8,'Pemasukan&nbsp;Lain-lain',4,4),(9,'Rekap Harian',4,2),(10,'Rekap Harian',6,2),(11,'Rekap Harian',8,2),(12,'Tambah Siswa',12,1),(13,'Edit Siswa',12,1),(14,'Edit Iuran',12,1),(15,'Tambah User',12,1);

/*Table structure for table `pub_grupMember` */

DROP TABLE IF EXISTS `pub_grupMember`;

CREATE TABLE `pub_grupMember` (
  `idGrup` int(11) NOT NULL auto_increment,
  `namaGrup` varchar(45) NOT NULL,
  `levelGrup` int(11) default NULL,
  PRIMARY KEY  (`idGrup`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `pub_grupMember` */

insert  into `pub_grupMember`(`idGrup`,`namaGrup`,`levelGrup`) values (1,'Administrator',1),(2,'Kep.Sekolah',2),(3,'Guru',3),(4,'Siswa/Wali',4);

/*Table structure for table `sis_Change` */

DROP TABLE IF EXISTS `sis_Change`;

CREATE TABLE `sis_Change` (
  `idChange` int(11) NOT NULL auto_increment,
  `tanggalChange` datetime NOT NULL,
  `nisSiswaChange` varchar(16) NOT NULL,
  `nominalChange` int(11) NOT NULL,
  PRIMARY KEY  (`idChange`),
  KEY `FK_nis_Change` (`nisSiswaChange`),
  CONSTRAINT `FK_nis_Change` FOREIGN KEY (`nisSiswaChange`) REFERENCES `sis_Siswa` (`nisSiswa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_Change` */

insert  into `sis_Change`(`idChange`,`tanggalChange`,`nisSiswaChange`,`nominalChange`) values (1,'2009-08-04 21:07:54','14765',630000),(2,'2009-08-04 08:08:42','14766',50000);

/*Table structure for table `sis_Kelas` */

DROP TABLE IF EXISTS `sis_Kelas`;

CREATE TABLE `sis_Kelas` (
  `idKelas` int(11) NOT NULL auto_increment,
  `namaKelas` varchar(32) NOT NULL,
  PRIMARY KEY  (`idKelas`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_Kelas` */

insert  into `sis_Kelas`(`idKelas`,`namaKelas`) values (1,'Akuntansi A'),(2,'TeKaJe'),(3,'Penjualan'),(4,'Restoran'),(5,'Tata Busana'),(6,'Akuntansi B');

/*Table structure for table `sis_Peminjaman` */

DROP TABLE IF EXISTS `sis_Peminjaman`;

CREATE TABLE `sis_Peminjaman` (
  `idPeminjaman` int(11) NOT NULL auto_increment,
  `tanggalPeminjaman` date NOT NULL,
  `namaPeminjam` varchar(64) NOT NULL,
  `nominalPeminjaman` int(11) NOT NULL,
  `statusPinjaman` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`idPeminjaman`)
) ENGINE=InnoDB AUTO_INCREMENT=2011 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_Peminjaman` */

insert  into `sis_Peminjaman`(`idPeminjaman`,`tanggalPeminjaman`,`namaPeminjam`,`nominalPeminjaman`,`statusPinjaman`) values (1,'2009-07-30','Drs Kamal Abdullah',500000,1),(2,'2009-07-30','Malik',200000,0),(3,'2009-07-30','Ardian',300000,0),(2010,'2009-08-04','Ardian',100000,0);

/*Table structure for table `sis_PengeluaranLain` */

DROP TABLE IF EXISTS `sis_PengeluaranLain`;

CREATE TABLE `sis_PengeluaranLain` (
  `idPengeluaranLain` int(11) NOT NULL auto_increment,
  `tanggalPengeluaranLain` date NOT NULL,
  `nominalPengeluaranLain` int(11) NOT NULL,
  `pjPengeluaranLain` varchar(64) NOT NULL,
  `keterangan` text,
  PRIMARY KEY  (`idPengeluaranLain`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_PengeluaranLain` */

insert  into `sis_PengeluaranLain`(`idPengeluaranLain`,`tanggalPengeluaranLain`,`nominalPengeluaranLain`,`pjPengeluaranLain`,`keterangan`) values (1,'2009-07-30',150000,'Erik','Beli Alat Kebersihan'),(2,'2009-07-30',200000,'Hatono','Membeli Alat Kebersihan untuk kelas-kelas');

/*Table structure for table `sis_Pengembalian` */

DROP TABLE IF EXISTS `sis_Pengembalian`;

CREATE TABLE `sis_Pengembalian` (
  `idKembali` int(11) NOT NULL auto_increment,
  `tanggalKembali` date NOT NULL,
  `namaPengembali` varchar(64) NOT NULL,
  `nominalKembali` int(11) NOT NULL,
  PRIMARY KEY  (`idKembali`)
) ENGINE=InnoDB AUTO_INCREMENT=2010 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_Pengembalian` */

insert  into `sis_Pengembalian`(`idKembali`,`tanggalKembali`,`namaPengembali`,`nominalKembali`) values (1,'2009-07-30','Malik',200000),(2,'2009-07-30','Ardian',300000),(3,'2009-07-31','Drs Kamal Abdullah',500000),(2009,'0000-00-00','500000',0);

/*Table structure for table `sis_RekapIuranSiswa` */

DROP TABLE IF EXISTS `sis_RekapIuranSiswa`;

CREATE TABLE `sis_RekapIuranSiswa` (
  `idRekap` int(11) NOT NULL auto_increment,
  `nisSiswaRekap` varchar(16) NOT NULL,
  `idnamaIuranRekap` int(11) NOT NULL,
  `nominalRekap` int(11) NOT NULL default '0',
  PRIMARY KEY  (`idRekap`),
  KEY `FK_nis_RekapIuranSiswa` (`nisSiswaRekap`),
  KEY `FK_namaiuran_RekapIuranSiswa` (`idnamaIuranRekap`),
  CONSTRAINT `FK_namaiuran_RekapIuranSiswa` FOREIGN KEY (`idnamaIuranRekap`) REFERENCES `sis_namaIuran` (`idNamaIuran`) ON UPDATE CASCADE,
  CONSTRAINT `FK_nis_RekapIuranSiswa` FOREIGN KEY (`nisSiswaRekap`) REFERENCES `sis_Siswa` (`nisSiswa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_RekapIuranSiswa` */

insert  into `sis_RekapIuranSiswa`(`idRekap`,`nisSiswaRekap`,`idnamaIuranRekap`,`nominalRekap`) values (1,'14765',1,200000),(2,'14765',2,50000),(3,'14765',3,70000),(4,'14765',4,50000),(5,'14765',5,2000000),(6,'14766',1,125000),(7,'14766',2,25000),(8,'14766',3,0),(9,'14766',4,0),(10,'14766',5,0),(11,'14769',1,0),(12,'14769',2,0),(13,'14769',3,0),(14,'14769',4,0),(15,'14769',5,0),(16,'14767',1,0),(17,'14767',2,0),(18,'14767',3,0),(19,'14767',4,0),(20,'14767',5,0),(21,'14768',1,0),(22,'14768',2,0),(23,'14768',3,0),(24,'14768',4,0),(25,'14768',5,0),(26,'14770',1,0),(27,'14770',2,0),(28,'14770',3,0),(29,'14770',4,0),(30,'14770',5,0),(31,'14771',1,0),(32,'14771',2,0),(33,'14771',3,0),(34,'14771',4,0),(35,'14771',5,0),(36,'14772',1,0),(37,'14772',2,0),(38,'14772',3,0),(39,'14772',4,0),(40,'14772',5,0);

/*Table structure for table `sis_Setoran` */

DROP TABLE IF EXISTS `sis_Setoran`;

CREATE TABLE `sis_Setoran` (
  `idSetoran` int(11) NOT NULL auto_increment,
  `tanggalSetoran` date NOT NULL,
  `idNamaSetoran` int(11) NOT NULL,
  `nominalSetoran` int(11) NOT NULL,
  PRIMARY KEY  (`idSetoran`),
  KEY `FK_jenis_Setoran` (`idNamaSetoran`),
  CONSTRAINT `FK_jenis_Setoran` FOREIGN KEY (`idNamaSetoran`) REFERENCES `sis_namaIuran` (`idNamaIuran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_Setoran` */

/*Table structure for table `sis_Siswa` */

DROP TABLE IF EXISTS `sis_Siswa`;

CREATE TABLE `sis_Siswa` (
  `nisSiswa` varchar(16) NOT NULL,
  `namaSiswa` varchar(45) NOT NULL,
  `jenjangKelas` int(11) NOT NULL,
  `idKelasSiswa` int(11) NOT NULL,
  `passwordSiswa` varchar(45) NOT NULL default '0',
  `nominalDPS` int(11) NOT NULL default '0',
  PRIMARY KEY  (`nisSiswa`),
  KEY `FK_sis_Siswa` (`idKelasSiswa`),
  CONSTRAINT `FK_sis_Siswa` FOREIGN KEY (`idKelasSiswa`) REFERENCES `sis_Kelas` (`idKelas`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `sis_Siswa` */

insert  into `sis_Siswa`(`nisSiswa`,`namaSiswa`,`jenjangKelas`,`idKelasSiswa`,`passwordSiswa`,`nominalDPS`) values ('14765','Muhammad Ardianto',2,1,'14765',2000000),('14766','Ardi Helmi',1,1,'14766',1000000),('14767','Ardiantsari',1,6,'14767',1500000),('14768','Ardiansyah',1,1,'14768',1000000),('14769','Ardidoang',1,1,'14769',1500000),('14770','Ardianduk',1,1,'14770',1000000),('14771','Muhtarom',1,1,'14771',2000000),('14772','Harjo Sukirno',1,1,'14772',1500000);

/*Table structure for table `sis_Transaksi` */

DROP TABLE IF EXISTS `sis_Transaksi`;

CREATE TABLE `sis_Transaksi` (
  `idTransaksi` int(11) NOT NULL auto_increment,
  `tanggalTransaksi` date NOT NULL,
  `nisSiswaTransaksi` varchar(16) NOT NULL,
  `idKategoriIuranTrans` int(11) NOT NULL,
  `nominalTransaksi` int(11) NOT NULL,
  PRIMARY KEY  (`idTransaksi`),
  KEY `FK_siswa_Transaksi` (`nisSiswaTransaksi`),
  KEY `FK_sisidKategori_Transaksi` (`idKategoriIuranTrans`),
  CONSTRAINT `FK_sisidKategori_Transaksi` FOREIGN KEY (`idKategoriIuranTrans`) REFERENCES `sis_kategoriIuran` (`idKategoriIuran`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_siswa_Transaksi` FOREIGN KEY (`nisSiswaTransaksi`) REFERENCES `sis_Siswa` (`nisSiswa`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_Transaksi` */

insert  into `sis_Transaksi`(`idTransaksi`,`tanggalTransaksi`,`nisSiswaTransaksi`,`idKategoriIuranTrans`,`nominalTransaksi`) values (1,'2009-07-29','14765',1,250000),(2,'2009-07-29','14765',2,50000),(3,'2009-07-29','14765',3,70000),(4,'2009-07-29','14765',4,50000),(5,'2009-07-29','14765',5,580000),(6,'2009-07-29','14766',1,250000),(7,'2009-07-29','14766',2,50000),(8,'2009-07-29','14766',3,70000),(9,'2009-07-29','14766',4,50000),(10,'2009-07-29','14766',5,580000),(11,'2009-07-29','14767',1,200000),(12,'2009-07-29','14767',2,50000),(13,'2009-07-29','14767',3,70000),(14,'2009-07-29','14767',4,50000),(15,'2009-07-29','14767',5,630000),(16,'2009-07-29','14768',1,200000),(17,'2009-07-29','14768',2,50000),(18,'2009-07-29','14768',3,70000),(19,'2009-07-29','14768',4,50000),(20,'2009-07-29','14768',5,630000),(21,'2009-07-29','14769',1,150000),(22,'2009-07-29','14769',2,50000),(23,'2009-07-29','14769',3,70000),(24,'2009-07-29','14769',4,50000),(25,'2009-07-29','14769',5,680000),(26,'2009-07-29','14770',1,150000),(27,'2009-07-30','14770',2,50000),(28,'2009-07-30','14770',3,70000),(29,'2009-07-30','14770',4,50000),(30,'2009-07-30','14770',5,680000),(31,'2009-07-30','14770',1,75000),(32,'2009-07-30','14770',2,25000);

/*Table structure for table `sis_historyPemasukan` */

DROP TABLE IF EXISTS `sis_historyPemasukan`;

CREATE TABLE `sis_historyPemasukan` (
  `idHistory` int(11) NOT NULL auto_increment,
  `tanggalMasuk` date NOT NULL,
  `idNamaPemasukan` int(11) NOT NULL,
  `nominalPemasukan` int(11) NOT NULL,
  `keterangan` varchar(255) default NULL,
  PRIMARY KEY  (`idHistory`),
  KEY `FK_sis_historyPemasukan` (`idNamaPemasukan`),
  CONSTRAINT `FK_sis_historyPemasukan` FOREIGN KEY (`idNamaPemasukan`) REFERENCES `sis_pemasukanLain` (`idPemasukan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_historyPemasukan` */

insert  into `sis_historyPemasukan`(`idHistory`,`tanggalMasuk`,`idNamaPemasukan`,`nominalPemasukan`,`keterangan`) values (1,'2009-07-27',4,1000000,'Penyewaan gedung serba guna selama 2 hari'),(2,'2009-07-27',3,1500000,''),(3,'2009-07-29',3,3000000,''),(4,'2009-07-27',4,400000,'Jualan Roti'),(5,'2009-07-29',2,5000000,''),(6,'2009-07-29',5,25000000,''),(7,'2009-08-02',1,1000000,''),(8,'2009-08-04',5,5000000,'');

/*Table structure for table `sis_kategoriIuran` */

DROP TABLE IF EXISTS `sis_kategoriIuran`;

CREATE TABLE `sis_kategoriIuran` (
  `idKategoriIuran` int(11) NOT NULL auto_increment,
  `idIuran` int(11) NOT NULL,
  `jenjangKelasIuran` int(11) NOT NULL,
  `nominalIuran` int(11) NOT NULL,
  `totalSemester` int(11) NOT NULL default '0',
  PRIMARY KEY  (`idKategoriIuran`),
  KEY `FK_jenjang_kategoriIuran` (`jenjangKelasIuran`),
  KEY `FK_sis_kategoriIuran` (`idIuran`),
  CONSTRAINT `FK_sis_kategoriIuran` FOREIGN KEY (`idIuran`) REFERENCES `sis_namaIuran` (`idNamaIuran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_kategoriIuran` */

insert  into `sis_kategoriIuran`(`idKategoriIuran`,`idIuran`,`jenjangKelasIuran`,`nominalIuran`,`totalSemester`) values (1,1,1,125000,750000),(2,2,0,25000,150000),(3,3,0,70000,70000),(4,4,0,50000,50000),(5,5,0,0,0),(6,1,2,100000,600000),(7,1,3,75000,450000);

/*Table structure for table `sis_namaIuran` */

DROP TABLE IF EXISTS `sis_namaIuran`;

CREATE TABLE `sis_namaIuran` (
  `idNamaIuran` int(11) NOT NULL auto_increment,
  `namaIuran` varchar(32) NOT NULL,
  `onRelation` int(11) NOT NULL,
  `onTempo` tinyint(1) NOT NULL,
  `notGeneral` tinyint(4) default NULL,
  PRIMARY KEY  (`idNamaIuran`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_namaIuran` */

insert  into `sis_namaIuran`(`idNamaIuran`,`namaIuran`,`onRelation`,`onTempo`,`notGeneral`) values (1,'Dana Komite',1,1,1),(2,'Dana TA',2,1,0),(3,'Dana Kesiswaan (OSIS)',4,0,0),(4,'Dana Prakerin',3,0,0),(5,'Dana Pengembangan Sekolah',5,0,1);

/*Table structure for table `sis_pemasukanLain` */

DROP TABLE IF EXISTS `sis_pemasukanLain`;

CREATE TABLE `sis_pemasukanLain` (
  `idPemasukan` int(11) NOT NULL auto_increment,
  `namaPemasukan` varchar(64) NOT NULL,
  `totalPemasukan` int(11) NOT NULL,
  PRIMARY KEY  (`idPemasukan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_pemasukanLain` */

insert  into `sis_pemasukanLain`(`idPemasukan`,`namaPemasukan`,`totalPemasukan`) values (1,'Dana BOS',26000000),(2,'Bantuan APBN',7000000),(3,'Bantuan APBD',3000000),(4,'Lain-Lain',1150000),(5,'Dana Sponsor',5000000);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
