<html><center>
	<head>
		<title>SMK N 2 Temanggung</title>
		<link rel="stylesheet" type="text/css" href="log.css"></link>
	</head>
	<body>
	<div id='bg'>
		<div id='log'>
			<form method="POST" action="verifikasi.php">
			<table>
				<tr><td><b>Username </b></td><td><input type="text" name="user"></input></td></tr>
				<tr><td><b>Password </b></td><td><input type="password" name="pass"></input></td></tr>
				<tr><td><b>Login As </b></td><td><select name="kategori">
				<?
					include("dbase.php");
					$message=$_GET['message'];
					$query=mysql_query("SELECT * FROM pub_grupMember");
					while($grupMember=mysql_fetch_array($query)){
						echo "<option selected value=".$grupMember['idGrup'].">".$grupMember['namaGrup']."</option>";					
					}
				?>
				</select></td></tr>
				<tr><td colspan=2 align="center" valign="bottom"><input type="submit" name="login" value="LOGIN"></td></tr>
			</table>
			</form>
			<?echo "<br /><h3>".$message."</h3>";?>
		</div>
	</body>
</center></html>
