<?
	session_start();
	if(isset($_POST['login'])){
		include("dbase.php");
		
		$user=$_POST['user'];
		$pass=$_POST['pass'];
		$kategori=$_POST['kategori'];
		
			if($_POST['kategori']==4){
				$query=mysql_query("SELECT * FROM sis_Siswa WHERE nisSiswa='$user'");
				$cek=mysql_num_rows($query);
				$data=mysql_fetch_array($query);
			
				if($cek!=NULL && $pass==$data['passwordSiswa']){
					$_SESSION['user']=$data['nisSiswa'];
					$_SESSION['grup']=4;
				
					header('location:pages/main.php?sheet=sheet-default/sis_detail');
				} else {
					header('location:index.php?message=Login Gagal, silahkan Cek Ulang Username dan Password anda');			
				}
			} else {
				$query=mysql_query("SELECT * FROM pub_Member where namaMember='$user'");
				$cek=mysql_num_rows($query);
				$data=mysql_fetch_array($query);
		
				if($cek!=NULL && $pass==$data['passwordMember']){
					$_SESSION['user']=$data['idMember'];
					$_SESSION['grup']=$data['grupMember'];
			
					header('location:pages/main.php');
				} else {
					header('location:index.php?message=Login Gagal, silahkan Cek Ulang Username dan Password anda');
				}
			}
	}
?>