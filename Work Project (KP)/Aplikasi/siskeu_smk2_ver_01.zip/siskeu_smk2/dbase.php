<?
	mysql_connect("localhost","root","");
	mysql_select_db("mykp_dbs");
?>