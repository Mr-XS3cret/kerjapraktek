<?
	session_start();
	include("include/function.php");
	
	if(isset($_SESSION['user'])){
		$user=$_SESSION['user'];
		$grup=$_SESSION['grup'];
		
		include ("../dbase.php");
?>
		<html>
		<head>
			<title>SMK N 2 Temanggung</title>
			<link rel="stylesheet" type="text/css" href="../style.css" />
		</head>
		<body>
			<div id='main'>
				<div id='header'></div>
				<div id='content'>
					<div id='left'><?include("menu.php");?></div>
					<div id='right'>
						<div id='isian'><?include("content.php");?></div>
					</div>
				</div>
				<div id='footer' align=center>
				</div>
			</div>
		</body>
		</html>
<?
	} else {
		header('location:../index.php');
	}
?>	
