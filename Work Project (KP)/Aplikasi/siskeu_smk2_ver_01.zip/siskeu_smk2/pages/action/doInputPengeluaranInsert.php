<?
	include("../../dbase.php");	
	
	$nominal=$_POST['nominal'];
	$pjname=$_POST['pjname'];
	$keterangan=$_POST['keterangan'];
	
	if((!$nominal)||(!$pjname)){
		header('location:../main.php?sheet=outcome&&err=Input Gagal, Please Try Again');
	} else {
		$queryKeluar=mysql_query("insert into sis_PengeluaranLain values('',NOW(),'$nominal','$pjname','$keterangan')");
		if(!$queryKeluar){
			header('location:../main.php?sheet=outcome&&err=Input Rekap Gagal, Please Try Again');
		} else {
			header('location:../main.php?sheet=outcome&&err=Input Berhasil');
		}
	}
?>
