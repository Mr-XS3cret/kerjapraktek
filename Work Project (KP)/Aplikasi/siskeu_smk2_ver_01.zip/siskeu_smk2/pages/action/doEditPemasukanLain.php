<?
	session_start();
	include("../../dbase.php");
	
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
		$id=$_GET['id'];
		$nominal=(int)$_POST['nominal'];
		$pemasukan=$_POST['pemasukan'];
		$keterangan=$_POST['keterangan'];
		$tanggal=$_POST['tanggal'];
		
		if((!$nominal)||(!$pemasukan)||(!$tanggal)){
			header('location:../main.php?sheet=rekap-lain&subs=8&err=Edit Gagal, isi semua field data yang harus diisi dengan benar, coba ulangi kembali');
		} else {
			if($nominal==0){
				header('location:../main.php?sheet=rekap-lain&subs=8&err=tidak boleh 0');
			} else {
				$sunting=mysql_query("update sis_historyPemasukan set tanggalMasuk='$tanggal', idNamaPemasukan='$pemasukan',
						nominalPemasukan='$nominal', keterangan='$keterangan' where idHistory='$id'");
				if($sunting){
					header('location:../main.php?sheet=rekap-lain&subs=8&err=Edit Berhasil');
				} else {
					header('location:../main.php?sheet=rekap-lain&subs=8&err=Edit Gagal');	
				}
			}
		}
	}
?>
