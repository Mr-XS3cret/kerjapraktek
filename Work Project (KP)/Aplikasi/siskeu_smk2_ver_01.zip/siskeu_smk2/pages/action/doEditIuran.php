<?
	include("../../dbase.php");
	
	$id=$_REQUEST['id'];
	$iuranNew=(int)$_REQUEST['iuranNew'];
	
	if((!$id)||(!$iuranNew)){
		header('location:../main.php?sheet=edit&subs=14&err=Edit Gagal, Isikan Data Dengan Benar Coba Ulangi Lagi');
	} else {
		if($iuranNew<0){
			header('location:../main.php?sheet=edit&subs=14&err=Isian Tidak Boleh Negatif');
		} else {
			$edit=mysql_query("update sis_kategoriIuran set nominalIuran='$iuranNew' where idKategoriIuran='$id'");
			if($edit){
				header('location:../main.php?sheet=edit&subs=14&err=Edit Berhasil');
			} else {
				header('location:../main.php?sheet=edit&subs=14&err=Edit Gagal');
			}
		}
	}
?>
