<?
	include("../../dbase.php");
	
	$nisSiswa=$_POST['nisSiswa'];
	$SPP=$_POST['SPP'];
	$TA=$_POST['TA'];
	$OSIS=$_POST['OSIS'];
	$PRAK=$_POST['PRAK'];
	$DPS=$_POST['DPS'];
	$SPPnow=$_POST['SPPnow'];
	$TAnow=$_POST['TAnow'];
	$OSISnow=$_POST['OSISnow'];
	$PRAKnow=$_POST['PRAKnow'];
	$DPSnow=$_POST['DPSnow'];
	$change=$_POST['Change'];

	if($change){
		mysql_query("insert into sis_Change values('', NOW(), '$nisSiswa', '$change')");	
	}
	
	if($SPPnow){
		mysql_query("update sis_RekapIuranSiswa set nominalRekap=$SPPnow WHERE nisSiswaRekap='$nisSiswa' AND idNamaIuranRekap=1");
		mysql_query("insert into sis_Transaksi values('',NOW(), '$nisSiswa', 1, '$SPP')");
	}
	if($TAnow){
		mysql_query("update sis_RekapIuranSiswa set nominalRekap=$TAnow WHERE nisSiswaRekap='$nisSiswa' AND idNamaIuranRekap=2");
		mysql_query("insert into sis_Transaksi values('',NOW(), '$nisSiswa', 2, '$TA')");
	}
	if($OSISnow){
		mysql_query("update sis_RekapIuranSiswa set nominalRekap=$OSISnow WHERE nisSiswaRekap='$nisSiswa' AND idNamaIuranRekap=3");
		mysql_query("insert into sis_Transaksi values('',NOW(), '$nisSiswa', 3, '$OSIS')");	
	}
	if($PRAKnow){
		mysql_query("update sis_RekapIuranSiswa set nominalRekap=$PRAKnow WHERE nisSiswaRekap='$nisSiswa' AND idNamaIuranRekap=4");
		mysql_query("insert into sis_Transaksi values('',NOW(), '$nisSiswa', 4, '$PRAK')");	
	}
	if($DPSnow){
		mysql_query("update sis_RekapIuranSiswa set nominalRekap=$DPSnow WHERE nisSiswaRekap='$nisSiswa' AND idNamaIuranRekap=5");
		mysql_query("insert into sis_Transaksi values('',NOW(), '$nisSiswa', 5, '$DPS')");	
	}
	
	
	$_SESSION['nisSiswa']=$nisSiswa;	
	header('Location:../main.php?sheet=cek/cekDetailSiswa');

?>
