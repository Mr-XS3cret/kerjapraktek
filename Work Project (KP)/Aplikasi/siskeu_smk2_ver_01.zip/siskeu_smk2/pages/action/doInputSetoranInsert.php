<?
	include("../../dbase.php");	
	
	$id=$_POST['idSetoran'];
	$nominal=$_POST['nominal'];
	
	if((!$id)||(!$nominal)){
		header('location:../main.php?sheet=setoran&&err=Input Gagal, Please Try Again');
	} else {
		$queryRekap=mysql_query("insert into sis_Setoran values('',NOW(),'$id','$nominal')");
		if(!$queryRekap){
			header('location:../main.php?sheet=setoran&&err=Input Gagal, Please Try Again');
		} else {
			header('location:../main.php?sheet=setoran&&err=Input Berhasil');
		}
	}
?>	
