<?
	session_start(); 
	
	include("../../dbase.php");
	
	$old=$_POST['old'];
	$new=$_POST['new'];
	$cek=$_POST['cek'];
	
	$id=$_SESSION['user'];
	$grup=$_SESSION['grup'];
	
	if($grup==4){
		$query=mysql_query("select passwordSiswa from sis_Siswa where nisSiswa='$id'");
	} else {
		$query=mysql_query("select passwordMember from pub_Member where idMember='$id'");
	}
	
	$oldPass=mysql_fetch_row($query);
	
	if($old!=$oldPass[0]){
		header('location:../main.php?sheet=pass&err=Password Lama Salah');
	} else {
		if($new!=$cek){
			header('location:../main.php?sheet=pass&err=Konfirmasi Password tidak sama');
		} else {
			if($grup==4){
				$edit=mysql_query("update sis_Siswa set passwordSiswa='$new' where nisSiswa='$id'");
			} else {
				$edit=mysql_query("update pub_Member set passwordMember='$new' where idMember='$id'");
			}
			
			if($edit){
				header('location:../main.php?sheet=pass&err=Edit Berhasil');
			} else {
				header('location:../main.php?sheet=pass&err=Edit Gagal');
			}
		}
	}
?>
	