<?
	session_start();
	
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
		$nama=$_POST['nama'];
		$nominal=(int)$_POST['nominal'];
		
		if((!$nominal)||(!$nama)){
			header('location:../main.php?sheet=setoran&&err=isi semua field data dengan benar');
		} else {
			if($nominal==0){
				header('location:../main.php?sheet=setoran&&err=tidak boleh 0');
			} else {
				$_SESSION['nominal']=$nominal;
				$_SESSION['nama']=$nama;
				header('location:../main.php?sheet=cek/cekInputPinjaman');
			}
		}
	}
?>
