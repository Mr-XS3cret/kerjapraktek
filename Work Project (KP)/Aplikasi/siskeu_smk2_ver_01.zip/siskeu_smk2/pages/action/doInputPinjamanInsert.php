<?
	include("../../dbase.php");	
	
	$nama=$_POST['nama'];
	$nominal=$_POST['nominal'];
	
	if((!$nama)||(!$nominal)){
		header('location:../main.php?sheet=input-bon&&err=Input Gagal, Please Try Again');
	} else {
		$queryRekap=mysql_query("insert into sis_Peminjaman values('',NOW(),'$nama','$nominal','')");
		if(!$queryRekap){
			header('location:../main.php?sheet=input-bon&&err=Input Gagal, Please Try Again');
		} else {
			header('location:../main.php?sheet=input-bon&&err=Input Berhasil');
		}
	}
?>	
