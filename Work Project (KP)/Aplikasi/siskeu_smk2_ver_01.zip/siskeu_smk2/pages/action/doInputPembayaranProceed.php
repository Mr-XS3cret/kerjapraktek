<?
	session_start();
	
	$_SESSION['idBayar']=$_GET['id'];
	$_SESSION['namaBayar']=$_GET['nama'];
	$_SESSION['nominalBayar']=(int)$_GET['nominal'];
	
	header('location:../main.php?sheet=cek/cekInputPembayaran');
?>
