<?
	session_start();
	
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
		$nominal=(int)$_POST['nominal'];
		$pjname=$_POST['pjname'];
		$keterangan=$_POST['keterangan'];
		
		if((!$nominal)||(!$pjname)){
			header('location:../main.php?sheet=outcome&&err=isi semua field data yang harus diisi dengan benar');
		} else {
			if($nominal==0){
				header('location:../main.php?sheet=outcome&&err=tidak boleh 0');
			} else {
				$_SESSION['nominal']=$nominal;
				$_SESSION['pjname']=$pemasukan;
				$_SESSION['keterangan']=$keterangan;
				header('location:../main.php?sheet=cek/cekInputPengeluaran');
			}
		}
	}
?>
