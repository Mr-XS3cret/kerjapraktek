<?
	session_start();
	include("../../dbase.php");
	
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
		$nisSiswa=$_POST['nisSiswa'];
		$nominal=(int)$_POST['nominal'];
		$iuran=$_POST['iuran'];
		$bulan=$_POST['bulan'];
		
		$count=count($iuran);
		$InitNominal=$nominal;
		
		$_SESSION['InitNominal']=$InitNominal;
		
		$queryCekSiswa=mysql_query("SELECT nisSiswa, namaSiswa, nominalDPS FROM sis_Siswa WHERE nisSiswa='$nisSiswa'");
		$CekSiswa=mysql_fetch_array($queryCekSiswa);

		$_SESSION['nisSiswa']=$CekSiswa['nisSiswa'];
		$_SESSION['namaSiswa']=$CekSiswa['namaSiswa'];
		$_SESSION['nominalDPS']=$CekSiswa['nominalDPS'];

		if((!$nisSiswa)||(!$nominal)||(!$iuran)){
			header('location:../main.php?sheet=input&&err=isi semua field data dengan benar');		
		} else {
			if($nisSiswa!=$CekSiswa['nisSiswa']){
				header('location:../main.php?sheet=input&&err=Siswa tidak terdaftar / NIS Salah');			
			} else {
					$i=0;
					while($i<$count){
						$queryTempo=mysql_query("SELECT onTempo FROM sis_namaIuran WHERE idNamaIuran='$iuran[$i]'");
						$Tempo=mysql_fetch_array($queryTempo);
						
						if(($Tempo['onTempo']==true)&&(!$bulan)){ 
							header('location:../main.php?sheet=input&err=Silahkan isi jumlah bulan untuk SPP/TA terlebih dahulu');																			
						} else {
							$querySiswa=mysql_query("SELECT jenjangKelas FROM sis_Siswa WHERE nisSiswa='$nisSiswa'");
							$KelasIuran=mysql_fetch_array($querySiswa);
							
							$queryGeneral=mysql_query("SELECT notGeneral FROM sis_namaIuran WHERE idNamaIuran='$iuran[$i]'");							
							$general=mysql_fetch_array($queryGeneral);							
							
							$seq=$iuran[$i];
							if(fetchIuran($KelasIuran['jenjangKelas'],$iuran[$i],$general['notGeneral'])!=0){
								if($Tempo['onTempo']==true){
									$Add[$seq]=fetchIuran($KelasIuran['jenjangKelas'],$iuran[$i],$general['notGeneral'])*$bulan;
									$nominal=$nominal-$Add[$seq];								
								} else {
									$Add[$seq]=fetchIuran($KelasIuran['jenjangKelas'],$iuran[$i],$general['notGeneral']);
									$nominal=$nominal-$Add[$seq];									
								}
							} else {
								if($nominal>=fetchDPS($nisSiswa)){
									$Add[$seq]=fetchDPS($nisSiswa);
									$nominal=$nominal-$Add[$seq];									
								} else {
									$Add[$seq]=$nominal;
									$nominal=0;								
								}
							}
						}
						$i++;						
					} //end-while
					
					if($nominal<0){
						header('location:../main.php?sheet=input&&err=Jumlah Yang Dibayarkan Tidak Mencukupi');					
					} else {
						$_SESSION['SPP']=$Add[1];
						$_SESSION['TA']=$Add[2];
						$_SESSION['OSIS']=$Add[3];
						$_SESSION['PRAK']=$Add[4];
						$_SESSION['DPS']=$Add[5];
						$_SESSION['change']=$nominal;
						
						$query_cek=mysql_query("SELECT jenjangKelas, nominalDPS FROM sis_Siswa WHERE nisSiswa='$nisSiswa'");
						$cek=mysql_fetch_array($query_cek);
						$idKelas=$cek['jenjangKelas'];
	
						$j=0;
						while($j<$count){
							$query_CurrentIuran=mysql_query("SELECT nominalRekap FROM sis_RekapIuranSiswa WHERE nisSiswaRekap='$nisSiswa' AND idNamaIuranRekap='$iuran[$j]'");						
							$CurrentIuran=mysql_fetch_array($query_CurrentIuran);
							
							$iur=$iuran[$j];
							$Current[$iur]=$CurrentIuran['nominalRekap'];							
							$j++;						
						}
			
						$SPPnow=$Current[1]+$Add[1];
						$TAnow=$Current[2]+$Add[2];
						$OSISnow=$Current[3]+$Add[3];
						$PRAKnow=$Current[4]+$Add[4];
						$DPSnow=$Current[5]+$Add[5];
						
						$_SESSION['SPPnow']=$SPPnow;
						$_SESSION['TAnow']=$TAnow;
						$_SESSION['OSISnow']=$OSISnow;
						$_SESSION['PRAKnow']=$PRAKnow;
						$_SESSION['DPSnow']=$DPSnow;
						
						if($SPPnow>(fetchIuran($idKelas,1,1)*12)){
								$kurangSPP=12-($Current[1]/fetchIuran($idKelas,1,1));
								$_SESSION['kurangSPP']=$kurangSPP." bulan";
								header('location:../main.php?sheet=input&&err=Iuran SPP hanya kurang');
						} elseif($TAnow>(fetchIuran($idKelas,2,0)*12)){
								$kurangTA=12-($Current[1]/fetchIuran($idKelas,2,0));
								$_SESSION['kurangTA']=$kurangTA." bulan";	
								header('location:../main.php?sheet=input&&err=Iuran TA hanya kurang');					
						} elseif($OSISnow>fetchIuran($idKelas,3,0)){
								header('location:../main.php?sheet=input&&err=Iuran OSIS Lunas');
						} elseif($PRAKnow>fetchIuran($idKelas,4,0)){
								header('location:../main.php?sheet=input&&err=Iuran Prakerin Lunas');
						} elseif($DPSnow>$cek['nominalDPS']){
								header('location:../main.php?sheet=input&&err=Iuran DPS Lunas');
						} else {						
							header('location:../main.php?sheet=cek/cekInputIuran');						
						}
					}
											
			}
		}
	}	
//----------------------------------------function---------------------------
	
	function fetchIuran($kelas,$cat,$gen){
		if($gen==true){
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE jenjangKelasIuran='$kelas' AND idIuran='$cat'");		
		} else {
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE idIuran='$cat'");		
		}
		
		$KategoriIuran=mysql_fetch_array($queryKategori);
		
		$value=$KategoriIuran['nominalIuran'];
		return $value;
	}
	
	function fetchDPS($nis){
		$queryDPS=mysql_query("SELECT nominalDPS FROM sis_Siswa WHERE nisSiswa='$nis'");
		$DPS=mysql_fetch_array($queryDPS);
		
		$value=$DPS['nominalDPS'];
		return $value;	
	}
?>
