<?
	session_start();
	include("../../dbase.php");
	
	$nis=$_POST['nis'];
	$nama=$_POST['nama'];
	$dps=(int)$_POST['dps'];
	$jurusan=$_POST['jurusan'];
	$kelas=$_POST['kelas'];
	
	$_SESSION['nisEdit']=$nis;
	
	$query=mysql_query("select idKelas from sis_Kelas where namaKelas='$jurusan'");
	$idKelas=mysql_fetch_array($query);
	
	if(($jurusan)&&($kelas)){
		mysql_query("update sis_Siswa set jenjangKelas='$kelas', idKelasSiswa='$idKelas[idKelas]' where nisSiswa='$nis'");
	}
	
	if((!$nis)||(!$nama)||(!$dps)){
		header('location:../main.php?sheet=edit&subs=13&err=Edit Gagal, Isikan Data Dengan Benar Coba Ulangi Lagi');
	} else {
		$edit=mysql_query("update sis_Siswa set nisSiswa='$nis', namaSiswa='$nama', nominalDPS='$dps' where nisSiswa='$nis'");
		if($edit){
			header('location:../main.php?sheet=edit&subs=13&err=Edit Berhasil');
		} else {
			header('location:../main.php?sheet=edit&subs=13&err=Edit Gagal, Coba Ulangi Lagi');
		}
	}
?>
