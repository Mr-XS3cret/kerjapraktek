<?
	include("../../dbase.php");	
	
	$id=$_POST['idPemasukan'];
	$nominal=$_POST['nominal'];
	$saldo=$_POST['saldoAkhir'];
	$keterangan=$_POST['keterangan'];
	
	if((!$id)||(!$saldo)){
		header('location:../main.php?sheet=input-lain&&err=Input Gagal, Please Try Again');
	} else {
		$queryRekap=mysql_query("UPDATE sis_pemasukanLain SET totalPemasukan='$saldo' WHERE idPemasukan='$id'");
		if(!$queryRekap){
			header('location:../main.php?sheet=input-lain&&err=Input Rekap Gagal, Please Try Again');
		} else {
			$queryHistory=mysql_query("insert into sis_historyPemasukan 
												values('',NOW(),'$id','$nominal','$keterangan')");
			header('location:../main.php?sheet=input-lain&&err=Input Berhasil');
		}
	}
?>	
