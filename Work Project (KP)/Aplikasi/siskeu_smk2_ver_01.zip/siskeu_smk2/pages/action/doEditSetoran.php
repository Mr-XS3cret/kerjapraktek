<?
	include("../../dbase.php");
	
	$id=$_POST['id'];
	$nominal=(int)$_POST['nominal'];
	$setoran=$_POST['setoran'];
	$tanggal=$_POST['tanggal'];
	
	if((!$id)||(!$nominal)||(!$setoran)||(!$tanggal)){
		header('location:../main.php?sheet=rekap-iuran&err=Edit Gagal, Isikan Data Dengan Benar Coba Ulangi Lagi');
	} else {
		$edit=mysql_query("update sis_Setoran set tanggalSetoran='$tanggal', idNamaSetoran='$setoran', nominalSetoran='$nominal' where idSetoran='$id'");
		if($edit){
			header('location:../main.php?sheet=rekap-iuran&err=Edit Berhasil');
		} else {
					header('location:../main.php?sheet=rekap-iuran&err=Edit Gagal');

		}
	}
?>