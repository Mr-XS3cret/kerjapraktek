<?
	include("../../dbase.php");

	$id=$_POST['id'];
	$nama=$_POST['nama'];
	$nominal=(int)$_POST['nominal'];
	$tanggal=$_POST['tanggal'];
	$status=$_POST['status'];

	if((!$id)||(!$nama)||(!$nominal)||(!$tanggal)){
		header('location:../main.php?sheet=rekap-bon&err=Edit Gagal, Isikan Data dengan Benar Coba Ulangi Lagi');
	} else {
		$edit=mysql_query("update sis_Peminjaman set tanggalPeminjaman='$tanggal', namaPeminjam='$nama', nominalPeminjaman='$nominal', statusPinjaman='$status' where idPeminjaman='$id'");
		if($edit){
			header('location:../main.php?sheet=rekap-bon&err=Edit Berhasil');
		} else {
			header('location:../main.php?sheet=rekap-bon&err=Edit Gagal');
		}
	}
?>