<?
	session_start();
	
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
		$nominal=(int)$_POST['nominal'];
		$setoran=$_POST['setoran'];
		
		if((!$nominal)||(!$setoran)){
			header('location:../main.php?sheet=setoran&&err=isi semua field data dengan benar');
		} else {
			if($nominal==0){
				header('location:../main.php?sheet=setoran&&err=tidak boleh 0');
			} else {
				$_SESSION['nominal']=$nominal;
				$_SESSION['setoran']=$setoran;
				header('location:../main.php?sheet=cek/cekInputSetoran');
			}
		}
	}
?>
