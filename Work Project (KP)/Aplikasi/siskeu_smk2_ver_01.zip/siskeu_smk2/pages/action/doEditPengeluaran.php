<?
	include("../../dbase.php");
	
	$id=$_REQUEST['id'];
	$pjLain=$_REQUEST['pjLainEdit'];
	$nom=(int)$_REQUEST['nomLainEdit'];
	$ket=$_REQUEST['ketLainEdit'];
	$tgl=$_REQUEST['tglLainEdit'];
	
	//print_r($_REQUEST);
	
	if((!$id)||(!$pjLain)||(!$nom)||(!$ket)||(!$tgl)){
		header('location:../main.php?sheet=rekap-out&err=Edit Gagal, Isikan Data dengan Benar Coba Ulangi Lagi');
	} else {
		$edit=mysql_query("update sis_PengeluaranLain set tanggalPengeluaranLain='$tgl', nominalPengeluaranLain='$nom', pjPengeluaranLain='$pjLain', keterangan='$ket' where idPengeluaranLain='$id'");
		if($edit){
			header('location:../main.php?sheet=rekap-out&err=Edit Berhasil');
		} else {
			header('location:../main.php?sheet=rekap-out&err=Edit Gagal');
		}
	}
?>
