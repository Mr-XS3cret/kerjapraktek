<?
	include("../../dbase.php");

	$id=$_REQUEST['id'];
	$nisSiswa=$_REQUEST['nisSiswa'];
	$nominal=(int)$_REQUEST['nominal'];
	$tanggal=$_REQUEST['tanggal'];
	
	if((!$id)||(!$nisSiswa)||(!$tanggal)){
		header('location:../main.php?sheet=search&err=Edit Gagal, Isikan Data Dengan Benar Coba Ulangi Lagi');
	} else {
		$queryCurrentTrans=mysql_query("select nominalTransaksi from sis_Transaksi where idTransaksi='$id'");
		$currentTrans=mysql_fetch_array($queryCurrentTrans);
	
		$queryId=mysql_query("SELECT idNamaIuran FROM sis_Transaksi JOIN sis_kategoriIuran ON idKategoriIuranTrans=idKategoriIuran JOIN sis_namaIuran ON idNamaIuran=idIuran WHERE idTransaksi='$id'");
		$idIuran=mysql_fetch_array($queryId);
		
		$queryRekap=mysql_query("SELECT nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap='$idIuran[idNamaIuran]' and nisSiswaRekap='$nisSiswa'");
		$rekap=mysql_fetch_array($queryRekap);
		
		$add=$nominal-$currentTrans['nominalTransaksi'];
		$addRekap=$rekap['nominalRekap']+$add;
		
		$updateTransaksi=mysql_query("update sis_Transaksi set tanggalTransaksi='$tanggal', nominalTransaksi='$nominal' where idTransaksi='$id' ");
		$updateRekap=mysql_query("update sis_RekapIuranSiswa set nominalRekap='$addRekap' where idNamaIuranRekap='$idIuran[idNamaIuran]' and nisSiswaRekap='$nisSiswa'");
		
		if(($updateTransaksi)&&($updateRekap)){
			header('location:../main.php?sheet=search&err=Edit Berhasil');
		} else {
			header('location:../main.php?sheet=search&err=Edit Gagal');
		}
	}
?>