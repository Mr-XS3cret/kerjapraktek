<?
	include("../../dbase.php");
	
	$id=$_POST['id'];
	$nama=$_POST['nama'];
	$nominal=$_POST['nominal'];
	
	if((!$id)||($nama)||($nominal)){
		$bayar=mysql_query("update sis_Peminjaman set statusPinjaman=1 where idPeminjaman='$id'");
		if($bayar){
			$pay=mysql_query("insert into sis_Pengembalian values(NOW(),'$nama', '$nominal', '')");
			if($pay){
				header('location:../main.php?sheet=rekap-bon&&err=Input Berhasil');
			} else {
				header('location:../main.php?sheet=rekap-bon&&err=Input Gagal, Please Try Again');
			}
		} else {
			header('location:../main.php?sheet=rekap-bon&&err=Input Gagal, Please Try Again');
		}
	} else {
		header('location:../main.php?sheet=rekap-bon&&err=Input Gagal, Please Try Again');
	}
?>
