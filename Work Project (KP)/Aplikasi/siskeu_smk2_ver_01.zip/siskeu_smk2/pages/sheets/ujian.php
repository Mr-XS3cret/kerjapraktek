<?
	session_start();
	$subs=$_GET['subs'];
	
	if((!$subs)||($subs==15)){
		if($_SESSION['user']==1){
			echo "<h4>Cetak Kartu Ujian</h4>
						<center>
							<form method='POST' action=''>
								Masukkan NIS : <input type='text' name='nisSiswa'></input>&nbsp;
								<input type='radio' name='choice' value='UTS'>UTS</input>&nbsp
								<input type='radio' name='choice' value='UAS'>UAS</input>&nbsp;&nbsp;
								<input type='submit' value='Cetak'>
							</form>
						</center>";
						
			if((!$_POST['nisSiswa'])||(!$_POST['choice'])){
				echo "<h3>Pilih UTS atau UAS</h3>";
			} else {
				$queryCek=mysql_query("select namaSiswa from sis_Siswa where nisSiswa='$_POST[nisSiswa]'");
				$cekSiswa=mysql_fetch_row($queryCek);
				
				if(!$cekSiswa[0]){
					echo "<h3>Siswa Tidak Ditemukan</h3>";
				} else {
					if($_POST['choice']==UTS){
												
						$querySPP=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran, sis_Siswa WHERE jenjangKelasIuran=jenjangKelas AND nisSiswa='$_POST[nisSiswa]'");
						$SPP=mysql_fetch_row($querySPP);
						$mustSPP=$SPP[0]*6;
						
						$queryForb=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=1 and nisSiswaRekap='$_POST[nisSiswa]'");
						$forbSPP=mysql_fetch_row($queryForb);
						
						$kurang=$forbSPP[0]-$mustSPP;
								
							if($forbSPP[0]<$mustSPP){
								echo "<h3>Maaf Siswa dengan NIS ".$_POST['nisSiswa']."<br /> atas nama ".$cekSiswa[0]." <br />Belum Bisa Ikut Ujian ".$_POST['choice']."</h3>";
							} else {
								echo "<h3>Ok Cetak</h3>";
							}
						 
					}elseif($_POST['choice']==UAS){
						
							$querySPP=mysql_query("SELECT nominalIuran, nominalDPS FROM sis_kategoriIuran, sis_Siswa WHERE jenjangKelasIuran=jenjangKelas AND nisSiswa='$_POST[nisSiswa]'");
							$SPP=mysql_fetch_row($querySPP);
							$mustSPP=$SPP[0]*12;
							$mustDPS=$SPP[1];
							
							$queryPrakerin=mysql_query("select nominalIuran from sis_kategoriIuran where idKategoriIuran=4");
							$mustPrakerin=mysql_fetch_row($queryPrakerin);
							
							$queryOSIS=mysql_query("select nominalIuran from sis_kategoriIuran where idKategoriIuran=3");
							$mustOSIS=mysql_fetch_row($queryOSIS);
							
							$queryForbSPP=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=1 and nisSiswaRekap='$_POST[nisSiswa]'");
							$forbSPP=mysql_fetch_row($queryForbSPP);
							
							$queryForbOSIS=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=3 and nisSiswaRekap='$_POST[nisSiswa]'");
							$forbOSIS=mysql_fetch_row($queryForbOSIS);
							
							$queryForbPrakerin=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=4 and nisSiswaRekap='$_POST[nisSiswa]'");
							$forbPrakerin=mysql_fetch_row($queryForbPrakerin);
							
							$queryForbDPS=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=5 and nisSiswaRekap='$_POST[nisSiswa]'");
							$forbDPS=mysql_fetch_row($queryForbDPS);
							
							$kurangSPP=$forbSPP[0]-$mustSPP;
							$kurangOSIS=$forbOSIS[0]-$mustOSIS[0];
							$kurangPrakerin=$forbPrakerin[0]-$mustPrakerin[0];
							$kurangDPS=$forbDPS[0]-$mustDPS;
									
							if(($forbSPP[0]<$mustSPP)||($forbOSIS[0]<$mustOSIS)||($forbPrakerin[0]<$mustPrakerin)||($forbDPS[0]<$mustDPS)){
								echo "<h3>Maaf Siswa dengan NIS ".$_POST['nisSiswa']."<br /> atas nama ".$cekSiswa[0]." <br />Belum Bisa Ikut Ujian ".$_POST['choice']."</h3>";
							} else {
								echo "<h3>Ok Cetak</h3>";
							}
						
					}
				}
			}
		}
	} else {
		echo "<form method='POST' action=''>";
		echo "<b>Jurusan&nbsp;</b><select name='jurusan'>";
			$query=mysql_query("SELECT idKelas, namaKelas FROM sis_Kelas ORDER BY namaKelas");
			echo "<option value=0 selected>--Pilih Jurusan--</option>";
			while($jurusan=mysql_fetch_array($query)){
				echo "<option value='".$jurusan['idKelas']."'>".$jurusan['namaKelas']."</option>";					
			}
		echo "</select>";
		echo "<b>&nbsp;&nbsp;Kelas&nbsp;</b><select name='kelas'>";
		echo "		<option value=0 selected>--Pilih Kelas--</option>
						<option value=1>1</option>
						<option value=2>2</option>	
						<option value=3>3</option>						
					</select>
				<input type='submit' value='Lihat'>
			</form>";
			
		$jurusan=$_POST['jurusan'];
		$kelas=$_POST['kelas'];
		
		if((!$kelas)&&(!$jurusan)){
			echo "<h4>Pilih Kelas dan Jurusan</h4>";
		} else {
			$query=mysql_query("select nisSiswa, namaSiswa from sis_Siswa where idKelasSiswa='$jurusan' and jenjangKelas='$kelas'");
			$queryKelas=mysql_query("select namaKelas from sis_Kelas where idKelas='$jurusan'");
			$namaKelas=mysql_fetch_row($queryKelas);
			
			echo "<h4>".$kelas." - ".$namaKelas[0]."</h4>";
			
			if($subs==16){
				echo  "<h4>Daftar siswa yang tidak bisa ikut Ujian Tengah Semester</h4>";
				echo "<table cellpadding=10 class='tablebod' align=center>
						<tr>
							<th class='tablebod'>No.</th>
							<th class='tablebod'>NIS</th>
							<th class='tablebod'>Nama</th>
							<th class='tablebod'>SPP Terbayar</th>
							<th class='tablebod'>Keterangan</th>
						</th>
					";
			
				$no=1;
				while($siswa=mysql_fetch_array($query)){
					$querySPP=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran, sis_Siswa WHERE jenjangKelasIuran=jenjangKelas AND nisSiswa='$siswa[nisSiswa]'");
					$SPP=mysql_fetch_row($querySPP);
					$mustSPP=$SPP[0]*6;
					
					$queryForb=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=1 and nisSiswaRekap='$siswa[nisSiswa]'");
					$forbSPP=mysql_fetch_row($queryForb);
					
					$kurang=$forbSPP[0]-$mustSPP;
							
					if($forbSPP[0]<$mustSPP){
						echo "<tr>
								<td class='tablebod'>".$no."</td>
								<td class='tablebod'>".$siswa['nisSiswa']."</td>
								<td class='tablebod'>".$siswa['namaSiswa']."</td>
								<td class='tablebod'>".$forbSPP[0]."</td>
								<td class='tablebod'>Kurang ".$kurang."</td>
							</tr>";
					}
					$no++;
				}
				echo "</table>";
				echo "<form method='POST' action='pdf/nouts.php' target=_blank>
						<input type='hidden' name=jurusan value=".$jurusan."></input>
						<input type='hidden' name=kelas value=".$kelas."></input>
						<input type='submit' value='cetak pdf'></input>
					</form>
					";
			} elseif($subs==17) {
				echo  "<h4>Daftar siswa yang tidak bisa ikut Ujian Akhir Semester</h4>";
				echo "<table cellpadding=10 class='tablebod' align=center>
						<tr>
							<th class='tablebod' rowspan=2>No.</th>
							<th class='tablebod' rowspan=2>NIS</th>
							<th class='tablebod' rowspan=2>Nama</th>
							<th class='tablebod' colspan=4>Kekurangan Dana</th>
						</tr>
						<tr>
							<th class='tablebod'>SPP</th>
							<th class='tablebod'>OSIS</th>
							<th class='tablebod'>Prakerin</th>
							<th class='tablebod'>DPS</th>
						</th>
					";
			
				$no=1;
				while($siswa=mysql_fetch_array($query)){
					$querySPP=mysql_query("SELECT nominalIuran, nominalDPS FROM sis_kategoriIuran, sis_Siswa WHERE jenjangKelasIuran=jenjangKelas AND nisSiswa='$siswa[nisSiswa]'");
					$SPP=mysql_fetch_row($querySPP);
					$mustSPP=$SPP[0]*12;
					$mustDPS=$SPP[1];
					
					$queryPrakerin=mysql_query("select nominalIuran from sis_kategoriIuran where idKategoriIuran=4");
					$mustPrakerin=mysql_fetch_row($queryPrakerin);
					
					$queryOSIS=mysql_query("select nominalIuran from sis_kategoriIuran where idKategoriIuran=3");
					$mustOSIS=mysql_fetch_row($queryOSIS);
					
					$queryForbSPP=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=1 and nisSiswaRekap='$siswa[nisSiswa]'");
					$forbSPP=mysql_fetch_row($queryForbSPP);
					
					$queryForbOSIS=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=3 and nisSiswaRekap='$siswa[nisSiswa]'");
					$forbOSIS=mysql_fetch_row($queryForbOSIS);
					
					$queryForbPrakerin=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=4 and nisSiswaRekap='$siswa[nisSiswa]'");
					$forbPrakerin=mysql_fetch_row($queryForbPrakerin);
					
					$queryForbDPS=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=5 and nisSiswaRekap='$siswa[nisSiswa]'");
					$forbDPS=mysql_fetch_row($queryForbDPS);
					
					$kurangSPP=$forbSPP[0]-$mustSPP;
					$kurangOSIS=$forbOSIS[0]-$mustOSIS[0];
					$kurangPrakerin=$forbPrakerin[0]-$mustPrakerin[0];
					$kurangDPS=$forbDPS[0]-$mustDPS;
							
					if(($forbSPP[0]<$mustSPP)||($forbOSIS[0]<$mustOSIS)||($forbPrakerin[0]<$mustPrakerin)||($forbDPS[0]<$mustDPS)){
						echo "<tr>
								<td class='tablebod'>".$no."</td>
								<td class='tablebod'>".$siswa['nisSiswa']."</td>
								<td class='tablebod'>".$siswa['namaSiswa']."</td>
								<td class='tablebod'>".$kurangSPP."</td>
								<td class='tablebod'>".$kurangOSIS."</td>
								<td class='tablebod'>".$kurangPrakerin."</td>
								<td class='tablebod'>".$kurangDPS."</td>
							</tr>";
					}
					$no++;
				}
				echo "</table>";
				echo "<form method='POST' action='pdf/nouas.php' target=_blank>
						<input type='hidden' name=jurusan value=".$jurusan."></input>
						<input type='hidden' name=kelas value=".$kelas."></input>
						<input type='submit' value='cetak pdf'></input>
					</form>
					";
			}
		}
	}
?>