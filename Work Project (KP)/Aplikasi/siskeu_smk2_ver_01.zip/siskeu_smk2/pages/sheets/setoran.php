<?
	session_start();
	$err=$_GET['err'];
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
		echo "<b>".$err."</b>";
?>
	<h3>Penyetoran Dana Iuran Siswa</h3> 
	<form method="POST" action="action/doInputSetoranProceed.php">
		<table width=100% align="center">
			<tr><td><b>Nominal Setoran</b></td><td><b>:</b></td><td><input type="text" name="nominal"></input></td></tr>
			<tr><td valign='top'><b>Jenis Setoran</b></td><td valign='top'><b>:</b></td>
				 <td>
				 	<?
				 		$query=mysql_query("select idNamaIuran, namaIuran from sis_namaIuran");
				 		while($check=mysql_fetch_array($query)){
							echo "<input type='radio' name='setoran' value=".$check['idNamaIuran'].">Setoran ".$check ['namaIuran']."</input><br />";							
						}
				 	?>
				 </td>
			</tr> 
			<tr><td colspan=3 align="center"><br /><input type="submit" value="Masukkan"><input type="Reset" value="Reset"></td></tr>
		</table>
	</form>
<?
	} else {
		header('Location:../../index.php?message=Silahkan Login Terlebih Dahulu');
	}
?>
