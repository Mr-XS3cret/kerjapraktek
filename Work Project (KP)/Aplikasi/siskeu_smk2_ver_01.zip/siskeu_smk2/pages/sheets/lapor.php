<?
	include("sheet-detail/form-tanggal.php");
	$tgl[0]=$_POST['tahun'];
	$tgl[1]=$_POST['bulan'];
	$tgl[2]=$_POST['tanggal'];	
	if((!$tgl[0])||(!$tgl[1])||(!$tgl[2])){
		echo "<h2>--Pilih Tanggal--</h2>";
	} else {
		$tanggal=implode("",$tgl);
		
		$queryKomite=mysql_query("SELECT SUM(nominalTransaksi) FROM sis_Transaksi, sis_Siswa, sis_kategoriIuran WHERE tanggalTransaksi='$tanggal' AND nisSiswa=nisSiswaTransaksi AND idKategoriIuran=idKategoriIuranTrans AND idKategoriIuranTrans=1");					
		$queryTA=mysql_query("SELECT SUM(nominalTransaksi) FROM sis_Transaksi, sis_Siswa, sis_kategoriIuran WHERE tanggalTransaksi='$tanggal' AND nisSiswa=nisSiswaTransaksi AND idKategoriIuran=idKategoriIuranTrans AND idKategoriIuranTrans=2");					
		$queryOSIS=mysql_query("SELECT SUM(nominalTransaksi) FROM sis_Transaksi, sis_Siswa, sis_kategoriIuran WHERE tanggalTransaksi='$tanggal' AND nisSiswa=nisSiswaTransaksi AND idKategoriIuran=idKategoriIuranTrans AND idKategoriIuranTrans=3");					
		$queryPrakerin=mysql_query("SELECT SUM(nominalTransaksi) FROM sis_Transaksi, sis_Siswa, sis_kategoriIuran WHERE tanggalTransaksi='$tanggal' AND nisSiswa=nisSiswaTransaksi AND idKategoriIuran=idKategoriIuranTrans AND idKategoriIuranTrans=4");					
		$queryDPS=mysql_query("SELECT SUM(nominalTransaksi) FROM sis_Transaksi, sis_Siswa, sis_kategoriIuran WHERE tanggalTransaksi='$tanggal' AND nisSiswa=nisSiswaTransaksi AND idKategoriIuran=idKategoriIuranTrans AND idKategoriIuranTrans=5");					
		$Komite=mysql_fetch_row($queryKomite);
		$TA=mysql_fetch_row($queryTA);
		$OSIS=mysql_fetch_row($queryOSIS);
		$Prakerin=mysql_fetch_row($queryPrakerin);
		$DPS=mysql_fetch_row($queryDPS);	
		$Iuran=$Komite[0]+$TA[0]+$OSIS[0]+$Prakerin[0]+$DPS[0];	
		$queryLain=mysql_query("SELECT SUM(nominalPemasukan) FROM sis_historyPemasukan WHERE tanggalMasuk='$tanggal'");
		$pemasukanLain=mysql_fetch_row($queryLain);	
		$queryPengembalian=mysql_query("SELECT SUM(nominalKembali) FROM sis_Pengembalian WHERE tanggalKembali='$tanggal'");
		$pengembalian=mysql_fetch_row($queryPengembalian);	
		$totalMasuk=$Iuran+$pemasukanLain[0]+$pengembalian[0];	
		$querySetoranSPP=mysql_query("SELECT SUM(nominalSetoran) FROM sis_Setoran WHERE idNamaSetoran=1 AND tanggalSetoran='$tanggal'");
		$querySetoranTA=mysql_query("SELECT SUM(nominalSetoran) FROM sis_Setoran WHERE idNamaSetoran=2 AND tanggalSetoran='$tanggal'");
		$querySetoranOSIS=mysql_query("SELECT SUM(nominalSetoran) FROM sis_Setoran WHERE idNamaSetoran=3 AND tanggalSetoran='$tanggal'");
		$querySetoranPrakerin=mysql_query("SELECT SUM(nominalSetoran) FROM sis_Setoran WHERE idNamaSetoran=4 AND tanggalSetoran='$tanggal'");
		$querySetoranDPS=mysql_query("SELECT SUM(nominalSetoran) FROM sis_Setoran WHERE idNamaSetoran=5 AND tanggalSetoran='$tanggal'");
		$setoranSPP=mysql_fetch_row($querySetoranSPP);
		$setoranTA=mysql_fetch_row($querySetoranTA);
		$setoranOSIS=mysql_fetch_row($querySetoranOSIS);
		$setoranPrakerin=mysql_fetch_row($querySetoranPrakerin);
		$setoranDPS=mysql_fetch_row($querySetoranDPS);
		$totalSetoran=$setoranSPP[0]+$setoranTA[0]+$setoranOSIS[0]+$setoranPrakerin[0]+$setoranDPS[0];
		$queryPinjaman=mysql_query("select SUM(nominalPeminjaman) from sis_Peminjaman where tanggalPeminjaman='$tanggal'");
		$pinjaman=mysql_fetch_row($queryPinjaman);
		$queryOther=mysql_query("select SUM(nominalPengeluaranLain) from sis_PengeluaranLain where tanggalPengeluaranLain='$tanggal'");
		$other=mysql_fetch_row($queryOther);
		$totalKeluar=$totalSetoran+$pinjaman[0]+$other[0];
		$saldo=$totalMasuk-$totalKeluar;
		if($tgl[1]) $bln=convert_Date($tgl[1]);
		echo "<h3>Rekapitulasi Harian tanggal ".$tgl[2]." - ".$bln." - ".$tgl[0]."</h3>";
		echo "<table cellpadding=5 border=0>
					<tr><td><b>Pemasukan</b></td><td>&nbsp;</td><td>&nbsp;</td></tr>
					<tr>
						<td>Pemasukan Iuran
							<table>
								<tr><td><li>Dana Iuran Komite<td><td>:</td><td>".$Komite[0]."</td></tr>
								<tr><td><li>Dana Tabungan Akhir<td><td>:</td><td>".$TA[0]."</td></tr>
								<tr><td><li>Dana Iuran Kesiswaan<td><td>:</td><td>".$OSIS[0]."</td></tr>
								<tr><td><li>Dana Prakerin<td><td>:</td><td>".$Prakerin[0]."</td></tr>
								<tr><td><li>Dana Pengembangan Sekolah<td><td>:</td><td>".$DPS[0]."</td></tr>
							</table>
						</td><td valign=top>:</td><td valign=top>".$Iuran."</td></tr>
					<tr><td>Pemasukan Lain</td><td>:</td><td>".$pemasukanLain[0]."</td></tr>
					<tr><td>Jumlah Pengembalian Pinjaman</td><td>:</td><td>".$pengembalian[0]."</td></tr>
					<tr><td><b>Total Pemasukan</b></td><td><b>:</b></td><td><b>".$totalMasuk."</b></td></tr>
					<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
					<tr><td><b>Pengeluaran</b></td><td>&nbsp;</td><td>&nbsp;</td></tr>
					<tr><td>Total Setoran
							<table>
								<tr><td><li>Setoran Iuran Komite<td><td>:</td><td>".$setoranSPP[0]."</td></tr>
								<tr><td><li>Setoran Tabungan Akhir<td><td>:</td><td>".$setoranTA[0]."</td></tr>
								<tr><td><li>Setoran Iuran Kesiswaan<td><td>:</td><td>".$setoranOSIS[0]."</td></tr>
								<tr><td><li>Setoran Prakerin<td><td>:</td><td>".$setoranPrakerin[0]."</td></tr>
								<tr><td><li>Setoran Pengembangan Sekolah<td><td>:</td><td>".$setoranDPS[0]."</td></tr>
							</table>
						</td><td valign=top>:</td><td valign=top>".$totalSetoran."</td></tr>
					<tr><td>Jumlah Peminjaman</td><td>:</td><td>".$pinjaman[0]."</td></tr>
					<tr><td>Jumlah Pengeluaran Lain</td><td>:</td><td>".$other[0]."</td></tr>
					<tr><td><b>Total Pengeluaran</b></td><td><b>:</b></td><td><b>".$totalKeluar."</b></td></tr>
					<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
					<tr><td><b>Dana tersisa hari ini</b></td><td><b>:</b></td><td><b>".$saldo."</b></td></tr>
				</table>
				";
			
		echo "<form method='POST' action='pdf/lapday.php' target=_blank>
				<input type='hidden' name='tanggal' value=".$tgl[2]."></input>
				<input type='hidden' name='bulan' value=".$bln."></input>
				<input type='hidden' name='tahun' value=".$tgl[0]."></input>
				<input type='hidden' name='Komite' value=".$Komite[0]."></input>
				<input type='hidden' name='TA' value=".$TA[0]."></input>
				<input type='hidden' name='OSIS' value=".$OSIS[0]."></input>
				<input type='hidden' name='Prakerin' value=".$Prakerin[0]."></input>
				<input type='hidden' name='DPS' value=".$DPS[0]."></input>
				<input type='hidden' name='Iuran' value=".$Iuran."></input>
				<input type='hidden' name='PemasukanLain' value=".$pemasukanLain[0]."></input>
				<input type='hidden' name='Pengembalian' value=".$pengembalian[0]."></input>
				<input type='hidden' name='totalMasuk' value=".$totalMasuk."></input>
				<input type='hidden' name='setoranSPP' value=".$setoranSPP[0]."></input>
				<input type='hidden' name='setoranTA' value=".$setoranTA[0]."></input>
				<input type='hidden' name='setoranOSIS' value=".$setoranOSIS[0]."></input>
				<input type='hidden' name='setoranPrakerin' value=".$setoranPrakerin[0]."></input>
				<input type='hidden' name='setoranDPS' value=".$setoranDPS[0]."></input>
				<input type='hidden' name='totalSetoran' value=".$totalSetoran."></input>
				<input type='hidden' name='pinjaman' value=".$pinjaman[0]."></input>
				<input type='hidden' name='other' value=".$other[0]."></input>
				<input type='hidden' name='totalKeluar' value=".$totalKeluar."></input>
				<input type='hidden' name='saldo' value=".$saldo."></input>
				<input type='submit' value='Print PDF'></input>
			</form>
			";
	}
?>
