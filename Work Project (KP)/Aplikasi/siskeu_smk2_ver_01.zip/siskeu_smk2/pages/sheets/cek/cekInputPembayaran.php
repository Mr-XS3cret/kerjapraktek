<?
	session_start();
	
	$id=$_SESSION['idBayar'];
	$nama=$_SESSION['namaBayar'];
	$nominal=$_SESSION['nominalBayar'];
	
	echo "Pada hari ini <b>".date("j F Y , g: i a")."</b><br /> <b>".$nama."</b> akan membayar pinjaman sebesar<b>".$nominal."</b>";
	
	unset($_SESSION['idBayar']);
	unset($_SESSION['namaBayar']);
	unset($_SESSION['nominalBayar']);
	
	echo "<br /><br /><table align='center'>
				<tr>
					<td>
						<form method='POST' action='../pages/action/doInputPembayaranInsert.php'>
							<input type='hidden' name='id' value='".$id."'></input>
							<input type='hidden' name='nama' value='".$nama."'></input>
							<input type='hidden' name='nominal' value='".$nominal."'></input>
							<input type='submit' value='OK'>
						</form>
					</td>
					<td align='left'>
						<form method='POST' action='../pages/main.php?sheet=rekap-bon'>
							<input type='submit' value='Cancel'></input>
						</form>
					</td>
				</tr>
			</table>	";
?>
