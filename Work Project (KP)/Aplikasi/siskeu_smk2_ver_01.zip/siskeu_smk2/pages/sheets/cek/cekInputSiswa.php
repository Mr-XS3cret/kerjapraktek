<?
	$nis=$_POST['nis'];
	$nama=$_POST['nama'];
	$dps=(int)$_POST['dps'];
	$jurusan=$_POST['jurusan'];
	$kelas=$_POST['kelas'];
	
	$queryIdKelas=mysql_query("select idKelas from sis_Kelas where namaKelas='$jurusan'");
	$idKelas=mysql_fetch_array($queryIdKelas);
	
	$query=mysql_query("select idNamaIuran from sis_namaIuran");
	$count=mysql_num_rows($query);
	
	if((!$nis)||(!$nama)||(!$dps)||(!$jurusan)||(!$kelas)){
		echo "Input Tidak lengkap / Salah<a href='../pages/main.php?sheet=edit&subs=12'>Ulangi Lagi</a>";
	} else {
		$insertSiswa=mysql_query("insert into sis_Siswa values('$nis','$nama','$kelas','$idKelas[idKelas]','$nis','$dps')");
		if($insertSiswa){
			for($i=1;$i<=$count;$i++){
				$insertRekap=mysql_query("insert into sis_RekapIuranSiswa values('','$nis','$i','')");
				if(!$insertRekap){
					$err='Ooops..ada sedikit error silahkan hubungi administrator';
				}
			}
			echo "Penambahan Berhasil <a href='../pages/main.php?sheet=edit&subs=12'>Tambah Data Lagi</a> <br/>";
			echo $err;
		}else{
			echo "NIS Sudah terpakai <a href='../pages/main.php?sheet=edit&subs=12'>Ulangi Lagi</a>";
		}
	}
?>
