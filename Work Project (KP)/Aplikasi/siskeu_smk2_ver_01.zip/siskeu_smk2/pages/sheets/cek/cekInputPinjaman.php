<?
	session_start();
	
	$nominal=$_SESSION['nominal'];
	$nama=$_SESSION['nama'];
	
	echo "Pada hari ini <b>".date("j F Y , g: i a")."</b><br /> Anda akan meminjamkan dana sebesar <b>".$nominal."</b> kepada<b>".$nama."</b>";
	
	unset($_SESSION['nominal']);
	unset($_SESSION['nama']);
			
	echo "<br /><br /><table align='center'>
				<tr>
					<td>
						<form method='POST' action='../pages/action/doInputPinjamanInsert.php'>
							<input type='hidden' name='nama' value='".$nama."'></input>
							<input type='hidden' name='nominal' value='".$nominal."'></input>
							<input type='submit' value='OK'>
						</form>
					</td>
					<td align='left'>
						<form method='POST' action='../pages/main.php?sheet=input-bon'>
							<input type='submit' value='Cancel'></input>
						</form>
					</td>
				</tr>
			</table>	";
?>
