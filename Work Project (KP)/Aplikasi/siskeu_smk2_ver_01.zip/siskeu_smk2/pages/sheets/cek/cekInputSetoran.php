<?
	session_start();
	
	$nominal=$_SESSION['nominal'];
	$setoran=$_SESSION['setoran'];
	
	$queryNama=mysql_query("select namaIuran from sis_namaIuran where idNamaIuran='$setoran'");
	$nama=mysql_fetch_array($queryNama);
	
	echo "Pada hari ini <b>".date("j F Y , g: i a")."</b><br /> Anda akan menyetorkan <b>".$nama['namaIuran']."</b> Sebesar <b>".$nominal."</b>";
	
	unset($_SESSION['nominal']);
	unset($_SESSION['setoran']);
			
	echo "<br /><br /><table align='center'>
				<tr>
					<td>
						<form method='POST' action='../pages/action/doInputSetoranInsert.php'>
							<input type='hidden' name='idSetoran' value='".$setoran."'></input>
							<input type='hidden' name='nominal' value='".$nominal."'></input>
							<input type='submit' value='OK'>
						</form>
					</td>
					<td align='left'>
						<form method='POST' action='../pages/main.php?sheet=setoran'>
							<input type='submit' value='Cancel'></input>
						</form>
					</td>
				</tr>
			</table>	";
?>
