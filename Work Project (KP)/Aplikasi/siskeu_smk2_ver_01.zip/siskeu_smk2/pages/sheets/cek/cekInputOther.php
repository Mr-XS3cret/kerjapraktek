<?
	session_start();
	
	$nominal=$_SESSION['other'];
	$pemasukan=$_SESSION['pemasukan'];
	$keterangan=$_SESSION['keterangan'];
	
	$query=mysql_query("select namaPemasukan, totalPemasukan from sis_pemasukanLain where idPemasukan='$pemasukan'");
	$data=mysql_fetch_array($query);
	
	$saldoAkhir=$nominal+$data['totalPemasukan'];

	echo "<h3>Pemasukan ".$data['namaPemasukan']."</h3><hr />";
	echo "Saldo Awal : ".$data['totalPemasukan']."<br /><br />";
	echo "Dana Tambahan";
	echo "<ul>
				<li>Jumlah : ".$nominal."</li>
				<li>Keterangan : ".$keterangan."</li>
			</ul><br />";
	echo "Saldo Akhir : ".$saldoAkhir."<br /><br />";
	
	unset($_SESSION['other']);
	unset($_SESSION['pemasukan']);
	unset($_SESSION['keterangan']);
	
			
	echo "<table align='left'>
				<tr>
					<td>
						<form method='POST' action='../pages/action/doInputPemasukanInsert.php'>
							<input type='hidden' name='idPemasukan' value='".$pemasukan."'></input>
							<input type='hidden' name='nominal' value='".$nominal."'></input>
							<input type='hidden' name='saldoAkhir' value='".$saldoAkhir."'></input>
							<input type='hidden' name='keterangan' value='".$keterangan."'></input>
							<input type='submit' value='OK'>
						</form>
					</td>
					<td align='left'>
						<form method='POST' action='../pages/main.php?sheet=input-lain'>
							<input type='submit' value='Cancel'></input>
						</form>
					</td>
				</tr>
			</table>	";
?>
