<?
	session_start();
	
	$InitNominal=$_SESSION['InitNominal'];	
	$nisSiswa=$_SESSION['nisSiswa'];
	$namaSiswa=$_SESSION['namaSiswa'];
	$SPP=$_SESSION['SPP'];
	$TA=$_SESSION['TA'];
	$OSIS=$_SESSION['OSIS'];
	$PRAK=$_SESSION['PRAK'];
	$DPS=$_SESSION['DPS'];
	$SPPnow=$_SESSION['SPPnow'];
	$TAnow=$_SESSION['TAnow'];
	$OSISnow=$_SESSION['OSISnow'];
	$PRAKnow=$_SESSION['PRAKnow'];
	$DPSnow=$_SESSION['DPSnow'];
	$change=$_SESSION['change'];
	$total=$InitNominal-$change;
	
		echo "NIS    : ".$nisSiswa."<br />";
		echo "Nama	 : ".$namaSiswa."<br /><hr />";
		echo "<table border='0' cellpadding='5'>
					<tr>
						<th>No</th> 
						<th>Jenis Iuran</th>
						<th></th> 					
						<th>Jumlah Dibayar</th> 
					</tr>
					<tr>
						<th>1</th>
						<td>Iuran Komite</td>
						<td>:</td>					
						<td align='right'>".$SPP."</td>
					</tr>
					<tr>
						<th>2</th>
						<td>Tabungan Akhir</td>
						<td>:</td>					
						<td align='right'>".$TA."</td>
					</tr>
					<tr>
						<th>3</th>
						<td>Iuran Kesiswaan</td>
						<td>:</td>					
						<td align='right'>".$OSIS."</td>
					</tr> 
					<tr>
						<th>4</th>
						<td>Dana Prakerin</td>
						<td>:</td>					
						<td align='right'>".$PRAK."</td>
					</tr>
					<tr>
						<th>5</th>
						<td>Cicilan DPS</td>
						<td>:</td>					
						<td align='right'>".$DPS."</td>
					</tr>
					<tr>
						<td colspan='2'>Jumlah Uang</td>
						<td colspan='2' align='right'>".$InitNominal."</td> 
					</tr>
					<tr>
						<td colspan='2'>Jumlah Dibayar</td>
						<td colspan='2' align='right'>".$total."</td> 
					</tr>
					<tr>
						<td colspan='2'>Kembalian</td>
						<td colspan='2' align='right'>".$change."</td> 
					</tr> 
				<table>";
		
		unset($_SESSION['SPP']);
		unset($_SESSION['TA']);
		unset($_SESSION['OSIS']);
		unset($_SESSION['PRAK']);
		unset($_SESSION['DPS']);
		unset($_SESSION['change']);
		unset($_SESSION['SPPnow']);
		unset($_SESSION['TAnow']);
		unset($_SESSION['OSISnow']);
		unset($_SESSION['PRAKnow']);
		unset($_SESSION['DPSnow']);
	
		echo "<table align='center'>
				<tr>
					<td>
						<form method='POST' action='../pages/action/doInputIuranInsert.php'>
							<input type='hidden' name='nisSiswa' value='".$nisSiswa."'></input>
							<input type='hidden' name='SPP' value='".$SPP."'></input>
							<input type='hidden' name='TA' value='".$TA."'></input>
							<input type='hidden' name='OSIS' value='".$OSIS."'></input>
							<input type='hidden' name='PRAK' value='".$PRAK."'></input>
							<input type='hidden' name='DPS' value='".$DPS."'></input>
							<input type='hidden' name='SPPnow' value='".$SPPnow."'></input>
							<input type='hidden' name='TAnow' value='".$TAnow."'></input>
							<input type='hidden' name='OSISnow' value='".$OSISnow."'></input>
							<input type='hidden' name='PRAKnow' value='".$PRAKnow."'></input>
							<input type='hidden' name='DPSnow' value='".$DPSnow."'></input>
							<input type='hidden' name='Change' value='".$change."'></input>
							<input type='submit' value='OK'></input>	
						</form>
					</td>
					<td>
						<form method='POST' action='../pages/main.php?sheet=input'>
							<input type='submit' value='Cancel'></input>
						</form>
					</td>
				</tr>
				</table>";
?>
	
