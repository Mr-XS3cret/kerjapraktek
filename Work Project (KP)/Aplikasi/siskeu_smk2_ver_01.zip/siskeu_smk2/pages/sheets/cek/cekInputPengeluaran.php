<?
	session_start();
	
	$nominal=$_SESSION['nominal'];
	$pjname=$_SESSION['pjname'];
	$keterangan=$_SESSION['keterangan'];
	
	echo "Pada hari ini <b>".date("j F Y , g: i a")."</b><br /> Anda akan mengeluarkan dana sebesar <b>".$nominal."</b> atas nama <b>".$pjname."</b> untuk keperluan <b>".$keterangan."</b>";
	
	unset($_SESSION['nominal']);
	unset($_SESSION['pjname']);
	unset($_SESSION['keterangan']);
	
	echo "<br /><br /><table align='center'>
				<tr>
					<td>
						<form method='POST' action='../pages/action/doInputPengeluaranInsert.php'>
							<input type='hidden' name='nominal' value='".$nominal."'></input>
							<input type='hidden' name='pjname' value='".$pjname."'></input>
							<input type='hidden' name='keterangan' value='".$keterangan."'></input>
							<input type='submit' value='OK'>
						</form>
					</td>
					<td align='left'>
						<form method='POST' action='../pages/main.php?sheet=outcome'>
							<input type='submit' value='Cancel'></input>
						</form>
					</td>
				</tr>
			</table>	";
?>
