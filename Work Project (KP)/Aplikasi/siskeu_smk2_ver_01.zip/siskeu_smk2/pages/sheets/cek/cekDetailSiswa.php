<?
	session_start();
	$nisSiswa=$_SESSION['nisSiswa'];
	
	if(!$nisSiswa){
		$nisSiswa=$_POST['nisSiswa'];
		$page='search';
		unset($_SESSION['nisSiswa']);
	} else {
		$page='input';
	}
	
	$query=mysql_query("SELECT nisSiswa, namaSiswa FROM sis_Siswa WHERE nisSiswa='$nisSiswa'");
	$sis_detail=mysql_fetch_array($query);
		
	echo "NIS : ".$sis_detail['nisSiswa']."<br />";
	echo "Nama : ".$sis_detail['namaSiswa']."<br /><hr />";
	
	$queryRekap=mysql_query("SELECT nisSiswa, jenjangKelas, idNamaIuran, namaIuran, onTempo, notGeneral, nominalRekap 										FROM sis_Siswa JOIN sis_RekapIuranSiswa ON nisSiswa=nisSiswaRekap JOIN sis_namaIuran ON 											idNamaIuran=idNamaIuranRekap WHERE nisSiswa='$nisSiswa'");
?>
	<table width='95%' align='center' cellpadding='5' border='1px'>
		<tr><th align='left'>No</th><th align='left'>Nama&nbsp;Iuran</th><th align='left'>Jumlah&nbsp;Terbayar</th><th align='left'>Kekurangan</th><th align='left'>Keterangan</th></tr>
<?	
	$no=1;
	while($detailRekap=mysql_fetch_array($queryRekap)){
		
		if(fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral'])!=0){			
			if($detailRekap['onTempo']==true){
				$kurang=fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral'])*12-$detailRekap['nominalRekap'];
				$Bulan=12-($detailRekap['nominalRekap']/fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral']));			
				$ketBulan="Kurang - ".$Bulan." Bulan";			
			} else {
				$kurang=fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral'])-$detailRekap['nominalRekap'];					
				$ketBulan='--';			
			}
		} else {
			$kurang=fetchDPS($detailRekap['nisSiswa'])-$detailRekap['nominalRekap'];
			$ketBulan='--';
		}
		
		echo "<tr><td>".$no."</td><td>".$detailRekap['namaIuran']."</td><td>".$detailRekap['nominalRekap']."</td><td>".$kurang."</td><td>".$ketBulan."</td></tr>";		
		$no++;	
	}

	echo "</table><br />";
	echo "<center>
				<form method='POST' action='../pages/main.php?sheet=".$page."'>
				<input type='submit' value='Sip'></input></form>
			</center>";

	
	function fetchIuran($kelas,$cat,$gen){
		if($gen==true){
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE jenjangKelasIuran='$kelas' AND idIuran='$cat'");		
		} else {
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE idIuran='$cat'");		
		}
		
		$KategoriIuran=mysql_fetch_array($queryKategori);
		
		$value=$KategoriIuran['nominalIuran'];
		return $value;
	}
	
	function fetchDPS($nis){
		$queryDPS=mysql_query("SELECT nominalDPS FROM sis_Siswa WHERE nisSiswa='$nis'");
		$DPS=mysql_fetch_array($queryDPS);
		
		$value=$DPS['nominalDPS'];
		return $value;	
	}
?>
