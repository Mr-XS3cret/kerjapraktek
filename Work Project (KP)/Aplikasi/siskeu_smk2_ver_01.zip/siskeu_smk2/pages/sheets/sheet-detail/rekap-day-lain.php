<?
	//melihat rekapitulasi harian untuk penerimaan dari sumber pendapatan lain di luar iuran siswa
	include('form-tanggal.php');

	$tgl[0]=$_POST['tahun'];
	$tgl[1]=$_POST['bulan'];
	$tgl[2]=$_POST['tanggal'];	
	
	if((!$tgl[0])||(!$tgl[1])||(!$tgl[2])){
		$tanggal=date('Ymd');
	} else {
		$tanggal=implode("",$tgl);
	}
	
	$queryDay=mysql_query("SELECT  namaPemasukan, nominalPemasukan, keterangan FROM sis_pemasukanLain, 							sis_historyPemasukan WHERE tanggalMasuk='$tanggal' AND idPemasukan=idNamaPemasukan");
	
	if($tgl[1]) $bln=convert_Date($tgl[1]);
		
	echo "<h3>Daftar Pemasukan Tanggal ".$tgl[2]." - ".$bln." - ".$tgl[0]."</h3>";
	
	echo "<hr /><br /><table border=1 cellpadding=10 >
				<tr>
					<th>No.</th>
					<th>Nama Pemasukan</th>
					<th>Nominal Pemasukan</th>
					<th>Keterangan</th>
				</tr>";
	$no=1;
	while($rekapDay=mysql_fetch_array($queryDay)){
		if(!$rekapDay['keterangan']){
			$keterangan='-------';
		} else {
			$keterangan=$rekapDay['keterangan'];
		}
		echo "<tr>
					<td>".$no."</td>
					<td>".$rekapDay['namaPemasukan']."</td>
					<td>".$rekapDay['nominalPemasukan']."</td>
					<td>".$keterangan."</td>";
		echo "</tr>";
		$no++;
	}
				
	echo "</table>";

	

?>
