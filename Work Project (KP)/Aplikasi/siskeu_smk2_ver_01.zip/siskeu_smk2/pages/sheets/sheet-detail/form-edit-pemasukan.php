<?
	$id=$_GET['id'];
	$subs=$_GET['subs'];
	
	if($subs==7){
		$action='action/doEditPemasukanTetap';
	} elseif($subs==8){
		$action='action/doEditPemasukanLain';
	}
	
	$query=mysql_query("select tanggalMasuk, idNamaPemasukan, nominalPemasukan, keterangan from sis_historyPemasukan where idHistory='$id'");
	$edit=mysql_fetch_array($query);
	
echo "<h3>Input Pemasukan Lain (non Iuran Siswa)</h3> 
			<form method='POST' action='".$action.".php?id=".$id."'>
				<table width=100% align='center'>
					<tr><td><b>Nominal Pemasukan</b></td><td><b>:</b></td>
						 <td><input type='text' name='nominal' value='".$edit['nominalPemasukan']."'></input></td>
					</tr>
					<tr><td valign='top'><b>Jenis Pemasukan</b></td><td valign='top'><b>:</b></td>
						 <td>";
						 	
						 		$query=mysql_query('select * from sis_pemasukanLain');
						 		while($check=mysql_fetch_array($query)){
						 			if ($edit['idNamaPemasukan']==$check['idPemasukan']){
						 				$default='CHECKED';
						 			} else {
						 				$default='';
						 			}
									echo "<input type='radio' name='pemasukan' ".$default." value='".$check['idPemasukan']."'>
													".$check['namaPemasukan']."</input><br />";							
								}
						 	
			echo "	 </td>
					</tr> 
					<tr><td valign='top'><b>Keterangan</b></td><td valign='top'><b>:</b>
						 </td><td><textarea name=keterangan rows=5 cols=24>".$edit['keterangan']."</textarea></td>
					</tr>
					<tr><td><b>Tanggal Masuk</b></td><td><b>:</b></td>
						 <td><input type='text' name='tanggal' value='".$edit['tanggalMasuk']."'></input></td>
					</tr>
					<tr><td colspan=3 align='center'>
						 <input type='submit' value='Edit'></td>
					</tr>
				</table>
			</form>";
?>
