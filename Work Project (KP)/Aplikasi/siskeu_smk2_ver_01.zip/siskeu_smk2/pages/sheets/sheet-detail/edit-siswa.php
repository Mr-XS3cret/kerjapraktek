<?
	session_start();
	$subs=$_GET['subs'];
	
	echo "<h3>Masukkan NIS Siswa yang Akan Diedit</h3>
				<center>
					<form method='POST' action='../pages/main.php?sheet=edit&subs=".$subs."'>
						Masukkan NIS : <input type='text' name='nisSiswa'></input>&nbsp;&nbsp;
						<input type='submit' value='OK'>
					</form>
				</center>";
	echo "<h3>".$_GET['err']."</h3>";
				
	if($_REQUEST['nisSiswa']){
		echo "<br /><hr /><h3>NIS : ".$_POST['nisSiswa']."</h3>";
		
		$querySiswa=mysql_query("select * from sis_Siswa where nisSiswa='$_REQUEST[nisSiswa]'");
		$siswa=mysql_fetch_array($querySiswa);
		
		$queryJr=mysql_query("select namaKelas from sis_Kelas where idKelas='$siswa[idKelasSiswa]'");
		$jurusan=mysql_fetch_array($queryJr);
		
		echo "<form method='POST' action='../pages/action/doEditSiswa.php?nis=".$_REQUEST['nisSiswa']."'>
					<table>
						<tr><td>Nomor Induk Siswa</td><td>:</td>
							 <td><input type='text' name='nis' value='".$siswa['nisSiswa']."'></input></td>
						</tr>
						<tr><td>Nama Siswa</td><td>:</td>
						    <td><input type='text' name='nama' value='".$siswa['namaSiswa']."'></input></td>
						</tr> 
						<tr><td>Nominal DPS</td><td>:</td>
							 <td><input type='text' name='dps' value='".$siswa['nominalDPS']."'></input></td>
						</tr> 
						<tr><td>Kelas Sekarang</td><td>:</td>
						 	 <td><b>".$siswa['jenjangKelas']."-".$jurusan['namaKelas']."</b></td>
						</tr>
						<tr><td>Kelas Baru</td><td>:</td>
							 <td>";
							 	echo "<select name='jurusan'>";
								$query=mysql_query("SELECT DISTINCT namaKelas FROM sis_Kelas ORDER BY namaKelas");
								echo "<option value=0 selected>--Pilih Jurusan--</option>";
								while($jur=mysql_fetch_array($query)){
									echo "<option value='".$jur['namaKelas']."'>".$jur['namaKelas']."</option>";					
								}
								echo "</select>&nbsp;&nbsp;";
								echo "<select name='kelas'>";
								echo "	<option value=0 selected>--Pilih Kelas--</option>
											<option value=1>1</option>
											<option value=2>2</option>	
											<option value=3>3</option>						
										</select>";
							 	
		echo "		 	</td>
						</tr>
						<tr>
							<td colspan=3 align='center'><br />
								 <input type='submit' value='OK'>
							 </td>
						</tr>  
					</table>
				</form>";
	}
	
	if($_SESSION['nisEdit']){
		$querySiswa=mysql_query("select * from sis_Siswa where nisSiswa='$_SESSION[nisEdit]'");
		$siswa=mysql_fetch_array($querySiswa);
		
		$queryJr=mysql_query("select namaKelas from sis_Kelas where idKelas='$siswa[idKelasSiswa]'");
		$jurusan=mysql_fetch_array($queryJr);
		
		echo "	<table>
						<tr><td>Nomor Induk Siswa</td><td>:</td><td>".$siswa['nisSiswa']."</td></tr>
						<tr><td>Nama Siswa</td><td>:</td><td>".$siswa['namaSiswa']."</td></tr> 
						<tr><td>Nominal DPS</td><td>:</td><td>".$siswa['nominalDPS']."</td></tr> 
						<tr><td>Kelas Sekarang</td><td>:</td>
						 	 <td><b>".$siswa['jenjangKelas']."-".$jurusan['namaKelas']."</b></td>
						</tr>
					</table>";
		unset($_SESSION['nisEdit']);
	}
	
	function fetchIuran($kelas,$cat,$gen){
		if($gen==true){
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE jenjangKelasIuran='$kelas' AND idIuran='$cat'");		
		} else {
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE idIuran='$cat'");		
		}
		
		$KategoriIuran=mysql_fetch_array($queryKategori);
		
		$value=$KategoriIuran['nominalIuran'];
		return $value;
	}
	
	function fetchDPS($nis){
		$queryDPS=mysql_query("SELECT nominalDPS FROM sis_Siswa WHERE nisSiswa='$nis'");
		$DPS=mysql_fetch_array($queryDPS);
		
		$value=$DPS['nominalDPS'];
		return $value;	
	}
?>
