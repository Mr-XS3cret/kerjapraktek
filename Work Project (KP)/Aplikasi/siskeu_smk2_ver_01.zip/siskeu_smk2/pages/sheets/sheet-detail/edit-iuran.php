<?
	$subs=$_GET['subs'];
	$id=$_GET['id'];
	
	echo "<h3>Kategori Iuran Siswa SMK N 2 Temanggung</h3>";
	
	echo "<table cellpadding=10 border=1 class='tablebod'>
				<tr>
					<th class='tablebod'>No.</th>
					<th class='tablebod'>Nama Iuran</th>
					<th class='tablebod'>Kelas</th>
					<th class='tablebod'>Nominal</th>
					<th class='tablebod'>Edit</th>
				</tr>";
	
				$queryIuran=mysql_query("SELECT namaIuran, idKategoriIuran, jenjangKelasIuran, nominalIuran FROM sis_namaIuran JOIN sis_kategoriIuran ON idNamaIuran=idIuran where nominalIuran>=0");
				$no=1;
				while($iuran=mysql_fetch_array($queryIuran)){
					if($iuran['jenjangKelasIuran']==0){
						$kelas='semuanya';
					} else {
						$kelas=$iuran['jenjangKelasIuran'];
					}
					echo "<tr>
								<td class='tablebod'>".$no."</tdh>
								<td class='tablebod'>".$iuran['namaIuran']."</td>
								<td class='tablebod'>".$kelas."</td>
								<td class='tablebod'>".$iuran['nominalIuran']."</td>
								<td class='tablebod'><a href='../pages/main.php?sheet=edit&subs=".$subs."&id=".$iuran['idKategoriIuran']."&nilai=".$iuran['nominalIuran']."&nama=".$iuran['namaIuran']."&kelas=".$kelas."'>edit</a></td>
						</tr>";
					$no++;
				}
			
	echo "</table><br />";
	
	echo "<h3>".$_GET['err']."</h3>";
	
	if($id){
		echo "<hr />";
		echo "".$_GET['nama']." kelas ".$_GET['kelas']."<br />";
		echo "<form method='POST' action='../pages/action/doEditIuran.php?id=".$id."'>
					<input type='text' name='iuranNew' value='".$_GET['nilai']."'></input>
					<input type='submit' value='Edit'></input>
				</form>
		
		";
	}
	
	
?>
