<?php
	$subs=$_GET['subs'];
	
	if($subs==6) {
		$pageSheet='rekap-iuran';
	} elseif($subs==9) {
		$pageSheet='rekap-lain';
	} elseif($subs==10) {
		$pageSheet='rekap-bon';
	} elseif($subs==11) {
		$pageSheet='rekap-out';
	} else {
		$pageSheet='lapor';
	}

	echo "<form method='POST' action='../pages/main.php?sheet=$pageSheet&subs=$subs'>";

	echo "<select name=tanggal>
     	      <option value=0 selected>Tanggal</option>
				<option value=01 >1</option>
				<option value=02 >2</option>
				<option value=03 >3</option>
				<option value=04 >4</option>
				<option value=05 >5</option>
				<option value=06 >6</option>
				<option value=07 >7</option>
				<option value=08 >8</option>
				<option value=09 >9</option>
				<option value=10 >10</option>
				<option value=11 >11</option>
				<option value=12 >12</option>
				<option value=13 >13</option>
				<option value=14 >14</option>
				<option value=15 >15</option>
				<option value=16 >16</option>
				<option value=17 >17</option>
				<option value=18 >18</option>
				<option value=19 >19</option>
				<option value=20 >20</option>
				<option value=21 >21</option>
				<option value=22 >22</option>
				<option value=23 >23</option>
				<option value=24 >24</option>
				<option value=25 >25</option>
				<option value=26 >26</option>
				<option value=27 >27</option>
				<option value=28 >28</option>
				<option value=29 >29</option>
				<option value=30 >30</option>
				<option value=31 >31</option>
   		</select> ";  
       
	echo "<select name=bulan>
				<option value=0 selected>Bulan</option>
				<option value=01 >Januari</option>
				<option value=02 >Februari</option>
				<option value=03 >Maret</option>
				<option value=04 >April</option>
				<option value=05 >Mei</option>
				<option value=06 >Juni</option>
				<option value=07 >Juli</option>
				<option value=08 >Agustus</option>
				<option value=09 >September</option>
				<option value=10 >Oktober</option>
				<option value=11 >November</option>
				<option value=12 >Desember</option>
      	</select> ";
      
	$thn_skrg=date("Y");
	echo "<select name=tahun>
      	<option value=0 selected>Tahun</option>";
      	for ($thn=2000;$thn<=$thn_skrg;$thn++){
       	 echo "<option value=$thn>$thn</option>";
      	}
   echo "</select>";

	echo "&nbsp;<input type='submit' value='OK'></input>";

	echo "</form>";
	
	function convert_Date($mn){
		switch($mn){
		case 01: $bulan='Januari';break;
		case 02: $bulan='Februari';break;
		case 03: $bulan='Maret';break;
		case 04: $bulan='April';break;
		case 05: $bulan='Mei';break;
		case 06: $bulan='Juni';break;
		case 07: $bulan='Juli';break;
		case '08': $bulan='Agustus';break;
		case '09': $bulan='September';break;
		case 10: $bulan='Oktober';break;
		case 11: $bulan='November';break;
		case 12: $bulan='Desember';break;
		}
		
		return $bulan;
	
	}
?>
