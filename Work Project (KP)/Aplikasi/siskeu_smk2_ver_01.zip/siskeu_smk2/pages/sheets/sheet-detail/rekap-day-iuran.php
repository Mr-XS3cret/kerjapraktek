<?
	//melihat rekapitulasi harian untuk penerimaan dana iuran siswa
	include('form-tanggal.php');

	$tgl[0]=$_POST['tahun'];
	$tgl[1]=$_POST['bulan'];
	$tgl[2]=$_POST['tanggal'];	
	
	if((!$tgl[0])||(!$tgl[1])||(!$tgl[2])){
		$tanggal=date('Ymd');
	} else {
		$tanggal=implode("",$tgl);
	}
	
	$queryRekap=mysql_query("SELECT nisSiswaTransaksi, namaSiswa, idIuran, nominalTransaksi FROM sis_Transaksi, 										sis_Siswa, sis_kategoriIuran WHERE tanggalTransaksi='$tanggal' AND 											nisSiswa=nisSiswaTransaksi AND idKategoriIuran=idKategoriIuranTrans order by 											nisSiswaTransaksi asc");
	
	if($tgl[1]) $bln=convert_Date($tgl[1]);
		
		echo "<h3>Daftar Penerimaan Iuran tanggal ".$tgl[2]." - ".$bln." - ".$tgl[0]."</h3>";
	
	echo "<hr /><br /><table border=1 cellpadding=10 >
				<tr>
					<th>No.</th>
					<th>NIS</th>
					<th>Nama Siswa</th>
					<th>Jenis Iuran</th>
					<th>Jumlah Pembayaran</th>
				</tr>";
	$no=1;
	while($rekapDay=mysql_fetch_array($queryRekap)){
	$queryIuran=mysql_query("select namaIuran from sis_namaIuran where idNamaIuran=$rekapDay[idIuran]");
	$namaIuran=mysql_fetch_array($queryIuran);
		echo "<tr>
					<td>".$no."</td>
					<td>".$rekapDay['nisSiswaTransaksi']."</td>
					<td>".$rekapDay['namaSiswa']."</td>
					<td>".$namaIuran['namaIuran']."</td>
					<td>".$rekapDay['nominalTransaksi']."</td>";
		echo"</tr>";
		$no++;
	}
	echo "</table>";

?>
