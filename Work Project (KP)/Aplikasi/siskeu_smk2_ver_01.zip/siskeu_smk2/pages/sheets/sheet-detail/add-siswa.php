<h3>Tambah Data Siswa</h3>
<form method='POST' action='../pages/main.php?sheet=cek/cekInputSiswa'>
	<table cellpadding=5 border=0>
		<tr><td><b>NIS</b></td><td>:</td><td><input type='text' name='nis' ></input></td></tr>
		<tr><td><b>Nama</b></td><td>:</td><td><input type='text' name='nama'></input></td></tr>
		<tr><td><b>Nominal DPS</b></td><td>:</td><td><input type='text' name='dps'></input></td></tr>
		<tr><td><b>Kelas</b></td><td>:</td>
			 <td>
			 <?
			 	echo "<select name='jurusan'>";
						$query=mysql_query("SELECT DISTINCT namaKelas FROM sis_Kelas ORDER BY namaKelas");
						echo "<option value=0 selected>--Pilih Jurusan--</option>";
						while($grupMember=mysql_fetch_array($query)){
							echo "<option value=".$grupMember['namaKelas'].">".$grupMember['namaKelas']."</option>";					
						}
				echo "</select>&nbsp;&nbsp;";
				echo "<b>&nbsp;&nbsp;Kelas&nbsp;</b><select name='kelas'>";
				echo "	<option value=0 selected>--Pilih Kelas--</option>
							<option value=1>1</option>
							<option value=2>2</option>	
							<option value=3>3</option>						
						</select>";
			?>
			</td>
		</tr>
		<tr><td colspan=3 align='center'><br /><input type='submit' value='OK'><input type='Reset' value='Reset'></td></tr>
	</table>
</form>
