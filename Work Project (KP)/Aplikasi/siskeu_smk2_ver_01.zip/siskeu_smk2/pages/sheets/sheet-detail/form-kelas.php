<?
	$subs=$_GET['subs'];
	
	echo "<form method='POST' action='../pages/main.php?sheet=rekap-iuran&subs=".$subs."'>";
	echo "<b>Jurusan&nbsp;</b><select name='jurusan'>";
		
		$query=mysql_query("SELECT DISTINCT namaKelas FROM sis_Kelas ORDER BY namaKelas");
		echo "<option value=0 selected>--Pilih Jurusan--</option>";
		while($grupMember=mysql_fetch_array($query)){
			echo "<option value='".$grupMember['namaKelas']."'>".$grupMember['namaKelas']."</option>";					
		}
	
	echo "</select>";
	echo "<b>&nbsp;&nbsp;Kelas&nbsp;</b><select name='kelas'>";
	echo "		<option value=0 selected>--Pilih Kelas--</option>
					<option value=1>1</option>
					<option value=2>2</option>	
					<option value=3>3</option>						
				</select>
			<input type='submit' value='Lihat'>
		</form>";
