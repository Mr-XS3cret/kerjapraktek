<?
	session_start();
	$err=$_GET['err'];
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
	
	echo "</b>".$err."<b>";
?>
	<h3>Input Pengeluaran</h3> 
	<form method="POST" action="action/doInputPengeluaranProceed.php">
		<table width=100% align="center">
			<tr><td><b>Nominal Pengeluaran</b></td><td><b>:</b></td><td><input type="text" name="nominal"></input></td></tr>
			<tr><td valign='top'><b>Penanggung Jawab</b></td><td valign='top'><b>:</b></td><td><input type="text" name="pjname"></input></td></tr> 
			<tr><td valign='top'><b>Keterangan</b></td><td valign='top'><b>:</b></td><td><textarea name=keterangan rows=5 cols=24></textarea></td></tr>
			<tr><td colspan=3 align="center"><br /><input type="submit" value="Masukkan"><input type="Reset" value="Reset"></td></tr>
		</table>
	</form>
<?
	} else {
		header('Location:../../index.php?message=Silahkan Login Terlebih Dahulu');
	}
?>
