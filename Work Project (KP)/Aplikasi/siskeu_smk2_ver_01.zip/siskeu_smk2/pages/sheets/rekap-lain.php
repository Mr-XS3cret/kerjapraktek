<?
	$subs=$_GET['subs'];
	$id=$_GET['id'];
	
	if(!$subs){
		echo "REKAPITULASI DANA PEMASUKAN NON IURAN SISWA";
	} elseif($subs==9) {
		include("sheet-detail/rekap-day-lain.php");
	} else {
		echo "<h4>".$_GET['err']."</h4>";
		if($subs==8){
			echo "<h3>Rekap pemasukan lain-lain</h3>";
			$queryRekap=mysql_query("SELECT keterangan, tanggalMasuk, nominalPemasukan, idHistory FROM sis_pemasukanLain JOIN sis_historyPemasukan ON idPemasukan=idNamaPemasukan WHERE idNamaPemasukan = 4");
			if($id){
				include("sheet-detail/form-edit-pemasukan.php");
			}
		} elseif($subs==7){
			echo "<h3>Rekap pemasukan tetap</h3>";
			$queryRekap=mysql_query("SELECT namaPemasukan, tanggalMasuk, nominalPemasukan, idHistory FROM sis_pemasukanLain JOIN sis_historyPemasukan ON idPemasukan=idNamaPemasukan WHERE idNamaPemasukan != 4");
			if($id){
				include("sheet-detail/form-edit-pemasukan.php");
			}
		}
		
		echo "<table cellpadding=10 border=1 class='tablebod'>
					<tr>
						<th class='tablebod'>No.</th>
						<th class='tablebod'>Nama Pemasukan</th>
						<th class='tablebod'>Tanggal Masuk</th>
						<th class='tablebod'>Nominal</th>
					</tr>";
					
		$no=1;
		while($data=mysql_fetch_row($queryRekap)){
			echo "<tr>
						<td class='tablebod'>".$no."</td>
						<td class='tablebod'>".$data[0]."</td>
						<td class='tablebod'>".$data[1]."</td>
						<td class='tablebod'>".$data[2]."</td>";
						if($_SESSION['grup']==1){
							echo "<td class='tablebod'><a href='../pages/main.php?sheet=rekap-lain&id=".$data[3]."&subs=".$subs."'>Edit</a></td>";
						}
			echo "</tr>";
			$no++;
		}
					
		echo "</table>";
	}
?>
