<?
	session_start();
	
	$subs=$_GET['subs'];
	$idSetoran=$_GET['id'];

	$jenjang=$_POST['kelas'];
	$jurusan=$_POST['jurusan'];

	$queryKelas=mysql_query("select idKelas from sis_Kelas where namaKelas='$jurusan'");
	$Kelas=mysql_fetch_array($queryKelas);
	
	switch($subs){
		case 1: $id=1; $nama='Iuran Komite';break;
		case 2: $id=2; $nama='Tabungan Akhir';break;
		case 3: $id=3; $nama='Iuran Kesiswaan';break;
		case 4: $id=4; $nama='Dana Prakerin';break;
		case 5: $id=5; $nama='Dana Pengembangan Sekolah';break;
		case 6: $id=6; $nama='Harian';break;		
	}
	
	if(!$subs){
		echo "<h3>REKAPITULASI DANA IURAN SISWA</h3>";
		
		echo "<table cellpadding=10 border=1 class='tablebod'>
				<tr>
					<th class='tablebod'>Nama Iuran</th>
					<th class='tablebod'>Jumlah Masuk</th>
					<th class='tablebod'>Jumlah Disetorkan</th>
				<tr>
			";
		
		$queryNama=mysql_query("select idNamaIuran, namaIuran from sis_namaIuran");
		while($nama=mysql_fetch_array($queryNama)){
			$queryMasuk=mysql_query("select sum(nominalRekap) from sis_RekapIuranSiswa where idnamaIuranrekap=$nama[idNamaIuran]");
			$masuk=mysql_fetch_row($queryMasuk);
			$querySetoran=mysql_query("SELECT SUM(nominalSetoran) FROM sis_Setoran WHERE idNamaSetoran=$nama[idNamaIuran]");
			$setoran=mysql_fetch_row($querySetoran);
			
			if(!$setoran[0]){
				$setoran=0;
			} else {
				$setoran=$setoran[0];
			}
			
			echo "<tr>
					<td class='tablebod'>".$nama['namaIuran']."</td>
					<td class='tablebod'>".$masuk[0]."</td>
					<td class='tablebod'>".$setoran."</td>
				</tr>
			";
		}
		echo "</table>";
		
		echo "<h3>".$_GET['err']."</h3>";
		
		if($idSetoran){
				$queryEdit=mysql_query("select tanggalSetoran, idNamaSetoran, nominalSetoran from sis_Setoran where idSetoran='$idSetoran'");
				$editSetoran=mysql_fetch_array($queryEdit);
				
				echo "<h3>Edit Penyetoran Dana Iuran Siswa</h3> 
						<form method='POST' action='action/doEditSetoran.php'>
							<input type='hidden' name='id' value='".$idSetoran."'></input>
							<table width=100% align='center'>
								<tr><td><b>Nominal Setoran</b></td><td><b>:</b></td><td><input type='text' name='nominal' value='".$editSetoran['nominalSetoran']."'></input></td></tr>
								<tr><td valign='top'><b>Jenis Setoran</b></td><td valign='top'><b>:</b></td>
									 <td>";
									 		$query=mysql_query("select idNamaIuran, namaIuran from sis_namaIuran");
									 		while($check=mysql_fetch_array($query)){
												if($check['idNamaIuran']==$editSetoran['idNamaSetoran']){
													$default='CHECKED';
												} else {
													$default=NULL;
												}
												echo "<input type='radio' name='setoran' ".$default." value=".$check['idNamaIuran'].">Setoran ".$check ['namaIuran']."</input><br />";							
											}
				echo "				 </td>
								<tr><td><b>Tanggal Penyetoran</b></td><td><b>:</b></td><td><input type='text' name='tanggal' value='".$editSetoran['tanggalSetoran']."'></input></td></tr>
								</tr> 
								<tr><td colspan=3 align='center'><br /><input type='submit' value='Edit'></td></tr>
							</table>
						</form>					
					";
			}
		
	} elseif($subs==6) {
		include("sheet-detail/rekap-day-iuran.php");
	} else {
		include("sheet-detail/form-kelas.php");
	
		if((!$jenjang)||(!$jurusan)){
			$total=mysql_query("select SUM(nominalRekap) from sis_RekapIuranSiswa where idNamaIuranRekap='$id'");
			$tot=mysql_fetch_row($total);
		
			echo "<h3>Rekapitulasi Pemasukan ".$nama."</h3>";
			echo "Total Pemasukan ".$nama." : <b>".$tot[0]."</b><hr />";
			echo "<h4>Reakapitulasi Dana yang Telah Disetorkan</h4>";
			echo "<table cellpadding=10 border=1 class='tablebod'>
						<tr>
							<th class='tablebod'>No.</th>
							<th class='tablebod'>Tanggal</th>
							<th class='tablebod'>Jumlah Setoran</th>
							<th class='tablebod'>Saldo</th>
						</tr>	
					";
			$no=1;
			$set=0;			
			$querySetoran=mysql_query("select idSetoran, tanggalSetoran, nominalSetoran from sis_Setoran where idNamaSetoran=$id");
			while($setoran=mysql_fetch_array($querySetoran)){
				$set=$set+$setoran['nominalSetoran'];
				$saldo=$tot[0]-$set;
				echo "<tr>
							<td class='tablebod'>".$no."</td>
							<td class='tablebod'>".$setoran['tanggalSetoran']."</td>
							<td class='tablebod'>".$setoran['nominalSetoran']."</td>
							<td class='tablebod'>".$saldo."</td>";
							if($_SESSION['grup']==1){
								echo "<td class='tablebod'><a href='../pages/main.php?sheet=rekap-iuran&id=".$setoran['idSetoran']."'>Edit</a></td>";
							}
				echo	"</tr>";
				$no++;
			}
			
			echo "</table>";
		} else {
			$queryRekap=mysql_query("SELECT nisSiswa, nominalDPS, namaSiswa, idKelasSiswa, nominalRekap FROM 													sis_Siswa JOIN sis_RekapIuranSiswa ON nisSiswaRekap=nisSiswa WHERE 													idnamaIuranRekap='$id' AND jenjangKelas='$jenjang' AND 
												idKelasSiswa='$Kelas[idKelas]'");

			echo "<hr /><h3>Rekapitulasi ".$nama." Kelas ".$jenjang." - ".$jurusan."</h3>";

			echo "<table cellpadding=5 border=1 class='tablebod'>
					<tr>
						<th class='tablebod'>No.</th>
						<th class='tablebod'>NIS</th>
						<th class='tablebod'>Nama Siswa</th>
						<th class='tablebod'>Jumlah Dibayar</th>
						<th class='tablebod'>Jumlah Belum Dibayar</th>
						<th class='tablebod'>Keterangan</th>
					</tr>			
				";
					$no=1;
					while($rekap=mysql_fetch_array($queryRekap)){
				
						$query=mysql_query("select jenjangKelas, onTempo, notGeneral from sis_Siswa, sis_namaIuran where 														nisSiswa=$rekap[nisSiswa] and idNamaIuran=$id");
						$result=mysql_fetch_array($query);
				
						if(fetchIuran($result['jenjangKelas'], $id,$result['notGeneral'])!=0){
							if($result['onTempo']==TRUE){
								$kurang=fetchIuran($result['jenjangKelas'], $id,$result['notGeneral'])*12-$rekap['nominalRekap'];
								$Bulan=12-($rekap['nominalRekap']/fetchIuran($result['jenjangKelas'], $id,$result['notGeneral']));
								$ketBulan= "Kurang - ".$Bulan." Bulan";
							} else {
								$kurang=fetchIuran($result['jenjangKelas'], $id,$result['notGeneral'])-$rekap['nominalRekap'];
								$ketBulan='--';
							}
						} else {
							$kurang=fetchDPS($rekap['nisSiswa'])-$rekap['nominalRekap'];
							$ketBulan="DPS : ".$rekap['nominalDPS'];
						}
				
						echo " <tr>
								<td class='tablebod'>".$no."</td>
								<td class='tablebod'>".$rekap['nisSiswa']."</td>
								<td class='tablebod'>".$rekap['namaSiswa']."</td>
								<td class='tablebod'>".$rekap['nominalRekap']."</td>
								<td class='tablebod'>".$kurang."</td>
								<td class='tablebod'>".$ketBulan."</td>";
						echo "</tr>";
						$no++;			
					}
			echo "</table>";
		}
	}
	
	function fetchIuran($kelas,$cat,$gen){
		if($gen==true){
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE jenjangKelasIuran='$kelas' AND idIuran='$cat'");		
		} else {
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE idIuran='$cat'");		
		}
		
		$KategoriIuran=mysql_fetch_array($queryKategori);
		
		$value=$KategoriIuran['nominalIuran'];
		return $value;
	}
	
	function fetchDPS($nis){
		$queryDPS=mysql_query("SELECT nominalDPS FROM sis_Siswa WHERE nisSiswa='$nis'");
		$DPS=mysql_fetch_array($queryDPS);
		
		$value=$DPS['nominalDPS'];
		return $value;	
	}
?>
