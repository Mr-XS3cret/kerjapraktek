<?
	session_start();
	$err=$_GET['err'];
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
	
	echo "<b>".$err."</b>";
?>
	<h3>Peminjaman Dana</h3> 
	<form method="POST" action="action/doInputPinjamanProceed.php">
		<table width=100% align="center">
			<tr><td><b>Nama Peminjam</b></td><td><b>:</b></td><td><input type="text" name="nama"></input></td></tr>
			<tr><td><b>Nominal Pinjaman</b></td><td><b>:</b></td><td><input type="text" name="nominal"></input></td></tr>
			<tr><td colspan=3 align="center"><br /><input type="submit" value="Masukkan"><input type="Reset" value="Reset"></td></tr>
		</table>
	</form>
<?
	} else {
		header('Location:../../index.php?message=Silahkan Login Terlebih Dahulu');
	}
?>
