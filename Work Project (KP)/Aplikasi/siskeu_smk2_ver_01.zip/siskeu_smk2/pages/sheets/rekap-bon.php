<?
	$subs=$_GET['subs'];
	$err=$_GET['err'];
	$id=$_GET['id'];
	
	if($id){
		$queryEdit=mysql_query("select tanggalPeminjaman, namaPeminjam, nominalPeminjaman, statusPinjaman from sis_Peminjaman where idPeminjaman='$id'");
		$editPinjam=mysql_fetch_array($queryEdit);
		
		echo "
			<h3>Edit Peminjaman Dana</h3> 
			<form method='POST' action='action/doEditPeminjaman.php'>
				<table width=100% align='center'>
					<input type='hidden' name='id' value='".$id."'></input>
					<tr><td><b>Nama Peminjam</b></td><td><b>:</b></td><td><input type='text' name='nama' value='".$editPinjam['namaPeminjam']."'></input></td></tr>
					<tr><td><b>Nominal Pinjaman</b></td><td><b>:</b></td><td><input type='text' name='nominal' value='".$editPinjam['nominalPeminjaman']."'></input></td></tr>
					<tr><td><b>Tanggal Peminjaman</b></td><td><b>:</b></td><td><input type='text' name='tanggal' value='".$editPinjam['tanggalPeminjaman']."'></input></td></tr>
					<tr><td><b>Status Pinjaman</b></td><td><b>:</b></td>
						<td>
							<input type='radio' name='status' CHECKED value='0'>Belum Dibayar</input>
							<input type='radio' name='status' value='1'>Sudah Dibayar</input>
						</td>
					</tr>
					<tr><td colspan=3 align='center'><br /><input type='submit' value='Masukkan'><input type='Reset' value='Reset'></td></tr>
				</table>
			</form>
		";
	}
	
	if(!$subs){
		$queryPinjam=mysql_query("select * from sis_Peminjaman order by statusPinjaman asc");
		
		echo "<h3>Daftar Peminjaman</h3>";
		
		echo "<table cellpadding=5 border=1 class='tablebod'>
					<tr>
						<th class='tablebod'>No.</th>
						<th class='tablebod'>Nama Peminjam</th>
						<th class='tablebod'>Tanggal Peminjaman</th>
						<th class='tablebod'>Nominal Pinjaman</th>
						<th class='tablebod'>Status Pinjaman</th>
						<th colspan=2 align=center class='tablebod'>Aksi</th>
					</tr>";
		
		$no=1;
		while($pinjam=mysql_fetch_array($queryPinjam)){
			if($pinjam['statusPinjaman']==0){
				$status='Belum Dibayar';
				$link='bayar';
			} else {
				$status='Sudah Dibayar';
				$link=NULL;
			}
			
			echo "<tr>
						<td class='tablebod'>".$no."</td>
						<td class='tablebod'>".$pinjam['namaPeminjam']."</td>
						<td class='tablebod'>".$pinjam['tanggalPeminjaman']."</td>
						<td class='tablebod'>".$pinjam['nominalPeminjaman']."</td>
						<td class='tablebod'>".$status."</td>
						<td class='tablebod'><a href='action/doInputPembayaranProceed.php?id=".$pinjam['idPeminjaman']."&nama=".$pinjam['namaPeminjam']."&nominal=".$pinjam['nominalPeminjaman']."'>".$link."</a></td>";
						if($_SESSION['grup']==1){
							echo "<td class='tablebod'><a href='../pages/main.php?sheet=rekap-bon&id=".$pinjam['idPeminjaman']."'>Edit</a></td>";
						}
			echo "</tr>";
			$no++;
		}
		
		echo "</table>";
		
			
	} else {
		include("sheet-detail/form-tanggal.php");
		
		$tgl[0]=$_POST['tahun'];
		$tgl[1]=$_POST['bulan'];
		$tgl[2]=$_POST['tanggal'];	
	
		if((!$tgl[0])||(!$tgl[1])||(!$tgl[2])){
			$tanggal=date('Ymd');
		} else {
			$tanggal=implode("",$tgl);
		}
		
		$queryPinjam=mysql_query("select namaPeminjam, nominalPeminjaman from sis_Peminjaman where tanggalPeminjaman='$tanggal'");
		
		if($tgl[1]) $bln=convert_Date($tgl[1]);
		
		echo "<h3>Daftar Peminjaman tanggal ".$tgl[2]." - ".$bln." - ".$tgl[0]."</h3>";
		
		echo "<table cellpadding=10 border=1>
				<tr>
					<th class='tablebod'>No.</th>
					<th class='tablebod'>Nama Peminjam</th>
					<th class='tablebod'>Nominal Pinjaman</th>
				</tr>
			";
		
		$no=1;
		while($pinjam=mysql_fetch_array($queryPinjam)){
			echo "<tr>
					<td class='tablebod'>".$no."</td>
					<td class='tablebod'>".$pinjam['namaPeminjam']."</td>
					<td class='tablebod'>".$pinjam['nominalPeminjaman']."</td>
				</tr>";
			$no++;
		}
		
		echo "</table>";
	}
?>
