<?
	session_start();
	$err=$_GET['err'];
	if((isset($_SESSION['grup']))&&($_SESSION['grup']==1)){
	
	$kurangSPP=$_SESSION['kurangSPP'];
	$kurangTA=$_SESSION['kurangTA'];
	echo "<b>".$err."</b>"; echo " "; echo "<b>".$kurangSPP."</b>"; echo "<b>".$kurangTA."</b>";
?>
	<h3>Input Data Iuran Siswa</h3> 
	<form method="POST" action="action/doInputIuranProceed.php">
		<table width=100% align="center">
			<tr><td><b>Nomor Induk Siswa</b></td><td><b>:</b></td><td><input type="text" name="nisSiswa"></input></td></tr> 
			<tr><td><b>Jumlah yang Dibayarkan</b></td><td><b>:</b></td><td><input type="text" name="nominal"></input></td></tr>
			<tr><td valign="top"><b>Jenis Pembayaran</b></td><td valign="top"><b>:</b></td>
				 <td align="left">
					 <?
					 	$query=mysql_query("SELECT * FROM sis_namaIuran");
						while($check=mysql_fetch_array($query)){
							echo "<input type='checkbox' name='iuran[]' value=".$check['idNamaIuran'].">".$check['namaIuran']."</input><br />";							
						}
						echo "<br /><br />*)Dana Komite & TA Untuk <select name='bulan'><option selected></option>";
						for($i=1;$i<=12;$i++){
							echo "<option value=".$i.">".$i."</option>";			
						}
						echo "</select> Bulan";	
					 ?>
					</td>
			</tr> 
			<tr><td colspan=3 align="center"><br /><input type="submit" value="Masukkan"><input type="Reset" value="Reset"></td></tr>
		</table>
	</form>
<?
	} else {
		header('Location:../../index.php?message=Silahkan Login Terlebih Dahulu');
	}
	
	unset($_SESSION['kurangSPP']);
	unset($_SESSION['kurangTA']);
?>
