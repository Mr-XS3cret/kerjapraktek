<?
	$subs=$_GET['subs'];
	
	if(!$subs){
		$subs=12;
	}
	if($subs==12){
		include("sheet-detail/add-siswa.php");
	} elseif($subs==13) {
		include("sheet-detail/edit-siswa.php");
	} elseif($subs==14) {
		include("sheet-detail/edit-iuran.php");
	} elseif($subs==15) {
		include("sheet-detail/naik-kelas.php");
	}
?>
	

