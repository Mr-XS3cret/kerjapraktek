<?
	session_start();
	
	if(isset($_SESSION['user'])){
		$user=$_SESSION['user'];
		$grup=$_SESSION['grup'];
		
		$query_name=mysql_query("SELECT * FROM pub_Member where idMember='$user'");
		$name=mysql_fetch_array($query_name);
		
		$query_grup=mysql_query("SELECT * FROM pub_grupMember where idGrup='$grup'");
		$grup_name=mysql_fetch_array($query_grup);
		
		echo "Selamat Datang <b>".$name['namaMember']."</b> Anda Login Sebagai <b>".$grup_name['namaGrup']."</b>";
	}
?>