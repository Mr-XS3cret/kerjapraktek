<?
	session_start();
		
	if(isset($_SESSION['user'])){
		$nisSiswa=$_SESSION['user'];
		$grup=$_SESSION['grup'];
		
		$query=mysql_query("SELECT namaSiswa FROM sis_Siswa WHERE nisSiswa='$nisSiswa'");
		$sis_detail=mysql_fetch_array($query);
		
		echo "Selamat Datang ".$sis_detail['namaSiswa']."<br /><hr />";
		echo "Rekap administrasi anda adalah sebagai berikut : <br /><br />";
		
		$queryRekap=mysql_query("SELECT nisSiswa, jenjangKelas, idNamaIuran, namaIuran, onTempo, notGeneral, nominalRekap FROM sis_Siswa JOIN sis_RekapIuranSiswa ON nisSiswa=nisSiswaRekap JOIN sis_namaIuran ON idNamaIuran=idNamaIuranRekap WHERE nisSiswa='$nisSiswa'");

	echo "<table width='95%' align='center' cellpadding='5' border='1px' class='tablebod'>
			<tr><th align='left' class='tablebod'>No</th>
				<th align='left' class='tablebod'>Nama&nbsp;Iuran</th>
				<th align='left' class='tablebod'>Jumlah&nbsp;Terbayar</th>
				<th align='left' class='tablebod'>Kekurangan</th>
				<th align='left' class='tablebod'>Keterangan</th>
			</tr>";

	$no=1;
	while($detailRekap=mysql_fetch_array($queryRekap)){
		
		if(fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral'])!=0){			
			if($detailRekap['onTempo']==true){
				$kurang=fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral'])*12-$detailRekap['nominalRekap'];
				$Bulan=12-($detailRekap['nominalRekap']/fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral']));			
				$ketBulan="kurang - ".$Bulan." Bulan";			
			} else {
				$kurang=fetchIuran($detailRekap['jenjangKelas'],$detailRekap['idNamaIuran'],$detailRekap['notGeneral'])-$detailRekap['nominalRekap'];					
				$ketBulan='--';			
			}
		} else {
			$kurang=fetchDPS($detailRekap['nisSiswa'])-$detailRekap['nominalRekap'];
			$ketBulan='--';
		}
		
		echo "<tr>
				<td class='tablebod'>".$no."</td>
				<td class='tablebod'>".$detailRekap['namaIuran']."</td>
				<td class='tablebod'>".$detailRekap['nominalRekap']."</td>
				<td class='tablebod'>".$kurang."</td>
				<td class='tablebod'>".$ketBulan."</td>
			</tr>";		
		$no++;	
	}

	echo "</table>";

	echo "<h3>Sejarah Transaksi</h3>";
		
		$queryHistory=mysql_query("SELECT idTransaksi, tanggalTransaksi, nominalTransaksi, namaIuran FROM sis_Transaksi JOIN sis_kategoriIuran ON idKategoriIuran=idKategoriIuranTrans JOIN sis_namaIuran ON idNamaIuran=idIuran WHERE nisSiswaTransaksi='$nisSiswa';");
	
		echo "<table width='95%' align='center' cellpadding='5' border='1px' class='tablebod'>
				<tr>
					<th align='left' class='tablebod'>No</th>
					<th align='left' class='tablebod'>Tanggal</th>
					<th align='left' class='tablebod'>Jenis Transaksi</th>
					<th align='left' class='tablebod'>Nominal</th>
					<th align='left' class='tablebod'></th>
				</tr>
			";
	
		$num=1;
		while($history=mysql_fetch_array($queryHistory)){
			echo "<tr>
					<td class='tablebod'>".$num."</td>
					<td class='tablebod'>".$history['tanggalTransaksi']."</td>
					<td class='tablebod'>".$history['namaIuran']."</td>
					<td class='tablebod'>".$history['nominalTransaksi']."</td>";
					if($_SESSION['grup']==1){
						echo " <td class='tablebod'><a href='../pages/main.php?sheet=search&id=".$history['idTransaksi']."&nisSiswa=".$nisSiswa."'>Edit</a></td>";
					}
			echo "</tr>";
			$num++;
		}
		
		echo "</table>";
	}

	function fetchIuran($kelas,$cat,$gen){
		if($gen==true){
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE jenjangKelasIuran='$kelas' AND idIuran='$cat'");		
		} else {
			$queryKategori=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran WHERE idIuran='$cat'");		
		}
		
		$KategoriIuran=mysql_fetch_array($queryKategori);
		
		$value=$KategoriIuran['nominalIuran'];
		return $value;
	}
	
	function fetchDPS($nis){
		$queryDPS=mysql_query("SELECT nominalDPS FROM sis_Siswa WHERE nisSiswa='$nis'");
		$DPS=mysql_fetch_array($queryDPS);
		
		$value=$DPS['nominalDPS'];
		return $value;	
	}	
?>
