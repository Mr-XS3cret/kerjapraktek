<?
	$subs=$_GET['subs'];
	$id=$_GET['id'];
	
	echo ".<h3>".$_GET['err']."</h3>";
	
	if($id){
		$queryValue=mysql_query("select * from sis_PengeluaranLain where idPengeluaranLain='$id'");
		$value=mysql_fetch_array($queryValue);
		
		echo "<h3>Edit Pengeluaran</h3>";
		
		echo "
			
			<table cellpadding=5>
			<form method='POST' action='action/doEditPengeluaran.php?id=".$id."'>
				<tr><td>Penanggung Jawab</td><td>:</td>
					 <td><input type='text' name='pjLainEdit' value=".$value['pjPengeluaranLain']."></input></td>
				</tr>
				<tr><td>Nominal</td><td>:</td>
					 <td><input type='text' name='nomLainEdit' value=".$value['nominalPengeluaranLain']."></input></td>
				</tr>
				<tr><td>Keterangan</td><td>:</td>
					 <td><textarea name=ketLainEdit >".$value['keterangan']."</textarea></td>
				</tr>
				<tr><td>Tanggal</td><td>:</td>
					<td><input type='text' name='tglLainEdit' value=".$value['tanggalPengeluaranLain']."></input></td>
				</tr>
				<tr><td colspan=3 align=center><input type='submit' value='Edit'></td></tr>
			</form>
			</table><hr />
		";
	}
	
	if(!$subs){
		echo "<h3>REKAPITULASI PENGELUARAN</h3>";
		
		$queryPengeluaran=mysql_query("select idPengeluaranLain, tanggalPengeluaranLain, nominalPengeluaranLain, pjPengeluaranLain, keterangan from sis_PengeluaranLain order by tanggalPengeluaranLain desc");
	
		echo "<table cellpadding=10 border=1 class='tablebod'>
					<tr>
						<th class='tablebod'>No.</th>
						<th class='tablebod'>Tanggal</th>
						<th class='tablebod'>Penanggung Jawab</th>
						<th class='tablebod'>Nominal Pengeluaran</th>
						<th class='tablebod'>Keterangan</th>
					</tr>";
		$no=1;
		while($keluar=mysql_fetch_array($queryPengeluaran)){
			echo "<tr>
						<td class='tablebod'>".$no."</td>
						<td class='tablebod'>".$keluar['tanggalPengeluaranLain']."</td>
						<td class='tablebod'>".$keluar['pjPengeluaranLain']."</td>
						<td class='tablebod'>".$keluar['nominalPengeluaranLain']."</td>
						<td class='tablebod'>".$keluar['keterangan']."</td>";
						if($_SESSION['grup']==1){
							echo "<td class='tablebod'><a href='../pages/main.php?sheet=rekap-out&id=".$keluar['idPengeluaranLain']."'>Edit</a></td>";
						}
			echo "</tr>";
			$no++;
		}
		echo "</table>";
		
	} else {
		include("sheet-detail/form-tanggal.php");
		
		$tgl[0]=$_POST['tahun'];
		$tgl[1]=$_POST['bulan'];
		$tgl[2]=$_POST['tanggal'];	
	
		if((!$tgl[0])||(!$tgl[1])||(!$tgl[2])){
			$tanggal=date('Ymd');
		} else {
			$tanggal=implode("",$tgl);
		}
		
		$queryKeluar=mysql_query("select nominalPengeluaranLain, pjPengeluaranLain, keterangan from sis_PengeluaranLain where tanggalPengeluaranLain='$tanggal'");
		
		if($tgl[1]) $bln=convert_Date($tgl[1]);
		
		echo "<h3>Daftar Pengeluaran tanggal ".$tgl[2]." - ".$bln." - ".$tgl[0]."</h3>";
	
		echo "<table cellpadding=10 border=1>
					<tr>
						<th>No.</th>
						<th>Penanggung Jawab</th>
						<th>Nominal Pengeluaran</th>
						<th>Keterangan</th>
					</tr>";
		$no=1;
		while($keluar=mysql_fetch_array($queryKeluar)){
			echo "<tr>
						<td>".$no."</td>
						<td>".$keluar['pjPengeluaranLain']."</td>
						<td>".$keluar['nominalPengeluaranLain']."</td>
						<td>".$keluar['keterangan']."</td>
					</tr>";
			$no++;
		}
					
		echo "</table>";
	}
?>
