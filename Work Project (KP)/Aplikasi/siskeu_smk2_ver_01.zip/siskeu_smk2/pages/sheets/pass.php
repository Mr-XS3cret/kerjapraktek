<?
	echo "<h3>Ganti Password</h3>";
	echo "<table cellpadding=5>
			<form method='POST' action='action/doEditPassword.php'>
			<tr><td>Masukkan Password Lama</td><td>:</td><td><input type='password' name='old'></input></td></tr>
			<tr><td>Masukkan Password Baru</td><td>:</td><td><input type='text' name='new'></input></td></tr>
			<tr><td>Masukkan Konfirm Password Baru</td><td>:</td><td><input type='text' name='cek'></input></td></tr>
			<tr><td colspan=3 align=center><input type='submit' value='OK'></input></td></tr>
			</form>
		</table>
		";
	echo "<h3>".$_GET['err']."</h3>";
?>
