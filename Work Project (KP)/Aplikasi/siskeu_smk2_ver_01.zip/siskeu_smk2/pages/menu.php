<?
	session_start();
	
	if(isset($_SESSION['user'])){
		$user=$_SESSION['user'];
		$grup=$_SESSION['grup'];
		
		include ("../dbase.php");	
		
		$memberGrup=mysql_query("SELECT * FROM pub_grupMember WHERE idGrup=$grup");
		$level=mysql_fetch_array($memberGrup);
		
		$queryMenu=mysql_query("SELECT idMenu, namaMenu FROM pub_Menu WHERE accesLevel>=$level[levelGrup] order by idMenu asc");
		
		while($menu=mysql_fetch_array($queryMenu)){			
			$query=mysql_query("SELECT * FROM pub_Sheet WHERE levelSheet >= $level[levelGrup] AND idMenu=$menu[idMenu]");		
			
			while($sheet=mysql_fetch_array($query)){
				echo "<a href='main.php?sheet=".$sheet[pageSheet]."' class='sheet'>".$sheet['namaSheet']."&nbsp;</a>";
				
				$subSheet=mysql_query("SELECT * from pub_SubSheet WHERE idSheet=$sheet[idSheet] AND levelSubSheet >= $level[levelGrup] ");
				while($subs=mysql_fetch_array($subSheet)){
					echo "<a href='main.php?sheet=".($sheet['pageSheet'])."&subs=".$subs['idSubSheet']."'class='subsheet'>".$subs['namaSubSheet']."&nbsp;</a>";				
				}	
			}
		}
		echo "<a href='main.php?sheet=pass' class='sheet'>Ganti Password</a>";
		echo "<a href='../logout.php' class='sheet'>Logout</a>";
	}
?>
