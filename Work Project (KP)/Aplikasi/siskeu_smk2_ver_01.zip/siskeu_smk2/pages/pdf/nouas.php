<?
	include("../../dbase.php");
	require('fpdf.php');
	
	$jurusan=$_POST['jurusan'];
	$kelas=$_POST['kelas'];
	
	$query=mysql_query("select nisSiswa, namaSiswa from sis_Siswa where idKelasSiswa='$jurusan' and jenjangKelas='$kelas'");
	$queryKelas=mysql_query("select namaKelas from sis_Kelas where idKelas='$jurusan'");
	$namaKelas=mysql_fetch_row($queryKelas);
	
	$pdf=new FPDF();
	$pdf->AddPage();
	$pdf->SetLeftMargin(20);
	
	$pdf->SetFont('times','B',16);
	$pdf->Cell(160,10,'Daftar Siswa Yang Tidak Bisa Ikut U A S',0,1,'C');
	$pdf->Cell(70,10,$kelas,0,0,'R');
	$pdf->Cell(90,10,$namaKelas[0],0,1,'L');
	$pdf->Cell(160,10,'',0,1,'C');
	
	$pdf->SetFont('times','B',11);
	$pdf->Cell(15,10,'No',1,0,'C');
	$pdf->Cell(15,10,'NIS',1,0,'C');
	$pdf->Cell(60,10,'Nama',1,0,'C');
	$pdf->Cell(80,10,'Kekurangan Dana',1,1,'C');
	$pdf->Cell(90,10,'',1,0,'C');
	$pdf->Cell(20,10,'SPP',1,0,'C');
	$pdf->Cell(20,10,'OSIS',1,0,'C');
	$pdf->Cell(20,10,'Prakerin',1,0,'C');
	$pdf->Cell(20,10,'DPS',1,1,'C');
	
	$pdf->SetFont('times','',11);
			
	$no=1;
	while($siswa=mysql_fetch_array($query)){
		$querySPP=mysql_query("SELECT nominalIuran, nominalDPS FROM sis_kategoriIuran, sis_Siswa WHERE jenjangKelasIuran=jenjangKelas AND nisSiswa='$siswa[nisSiswa]'");
		$SPP=mysql_fetch_row($querySPP);
		$mustSPP=$SPP[0]*12;
		$mustDPS=$SPP[1];
					
		$queryPrakerin=mysql_query("select nominalIuran from sis_kategoriIuran where idKategoriIuran=4");
		$mustPrakerin=mysql_fetch_row($queryPrakerin);
					
		$queryOSIS=mysql_query("select nominalIuran from sis_kategoriIuran where idKategoriIuran=3");
		$mustOSIS=mysql_fetch_row($queryOSIS);
					
		$queryForbSPP=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=1 and nisSiswaRekap='$siswa[nisSiswa]'");
		$forbSPP=mysql_fetch_row($queryForbSPP);
				
		$queryForbOSIS=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=3 and nisSiswaRekap='$siswa[nisSiswa]'");
		$forbOSIS=mysql_fetch_row($queryForbOSIS);
					
		$queryForbPrakerin=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=4 and nisSiswaRekap='$siswa[nisSiswa]'");
		$forbPrakerin=mysql_fetch_row($queryForbPrakerin);
					
		$queryForbDPS=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=5 and nisSiswaRekap='$siswa[nisSiswa]'");
		$forbDPS=mysql_fetch_row($queryForbDPS);
					
		$kurangSPP=$forbSPP[0]-$mustSPP;
		$kurangOSIS=$forbOSIS[0]-$mustOSIS[0];
		$kurangPrakerin=$forbPrakerin[0]-$mustPrakerin[0];
		$kurangDPS=$forbDPS[0]-$mustDPS;
							
		if(($forbSPP[0]<$mustSPP)||($forbOSIS[0]<$mustOSIS)||($forbPrakerin[0]<$mustPrakerin)||($forbDPS[0]<$mustDPS)){
			$pdf->Cell(15,7,$no,1,0,'L');
			$pdf->Cell(15,7,$siswa[nisSiswa],1,0,'L');
			$pdf->Cell(60,7,$siswa[namaSiswa],1,0,'L');
			$pdf->Cell(20,7,$kurangSPP,1,0,'R');
			$pdf->Cell(20,7,$kurangOSIS,1,0,'R');
			$pdf->Cell(20,7,$kurangPrakerin,1,0,'R');
			$pdf->Cell(20,7,$kurangDPS,1,1,'R');
			$no++;
		}
	}
	$pdf->Output();

?>