<?
	include("../../dbase.php");
	require('fpdf.php');
	
	$jurusan=$_POST['jurusan'];
	$kelas=$_POST['kelas'];
		
	$query=mysql_query("select nisSiswa, namaSiswa from sis_Siswa where idKelasSiswa='$jurusan' and jenjangKelas='$kelas'");
	$queryKelas=mysql_query("select namaKelas from sis_Kelas where idKelas='$jurusan'");
	$namaKelas=mysql_fetch_row($queryKelas);
			
	$pdf=new FPDF();
	$pdf->AddPage();
	$pdf->SetLeftMargin(20);
	
	$pdf->SetFont('times','B',16);
	$pdf->Cell(160,10,'Daftar Siswa Yang Tidak Bisa Ikut U T S',0,1,'C');
	$pdf->Cell(70,10,$kelas,0,0,'R');
	$pdf->Cell(90,10,$namaKelas[0],0,1,'L');
	$pdf->Cell(160,10,'',0,1,'C');
	
	$pdf->SetFont('times','B',12);
	$pdf->Cell(15,10,'No',1,0,'C');
	$pdf->Cell(15,10,'NIS',1,0,'C');
	$pdf->Cell(60,10,'Nama',1,0,'C');
	$pdf->Cell(40,10,'SPP Terbayar',1,0,'C');
	$pdf->Cell(30,10,'Kekurangan',1,1,'C');
	
	$pdf->SetFont('times','',12);
			
	$no=1;
	while($siswa=mysql_fetch_array($query)){
		$querySPP=mysql_query("SELECT nominalIuran FROM sis_kategoriIuran, sis_Siswa WHERE jenjangKelasIuran=jenjangKelas AND nisSiswa='$siswa[nisSiswa]'");
		$SPP=mysql_fetch_row($querySPP);
		$mustSPP=$SPP[0]*6;
				
		$queryForb=mysql_query("select nominalRekap from sis_RekapIuranSiswa where idNamaIuranRekap=1 and nisSiswaRekap='$siswa[nisSiswa]'");
		$forbSPP=mysql_fetch_row($queryForb);
					
		$kurang=$forbSPP[0]-$mustSPP;
							
		if($forbSPP[0]<$mustSPP){
			$pdf->Cell(15,7,$no,1,0,'L');
			$pdf->Cell(15,7,$siswa[nisSiswa],1,0,'L');
			$pdf->Cell(60,7,$siswa[namaSiswa],1,0,'L');
			$pdf->Cell(40,7,$forbSPP[0],1,0,'R');
			$pdf->Cell(30,7,$kurang,1,1,'R');
			$no++;
		}
		
	}
	$pdf->Output();
?>