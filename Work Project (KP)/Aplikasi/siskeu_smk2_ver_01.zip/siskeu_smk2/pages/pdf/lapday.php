<?
	include("../../dbase.php");
	require('fpdf.php');
	
	$tanggal=$_POST['tanggal'];
	$bulan=$_POST['bulan'];
	$tahun=$_POST['tahun'];
	$Komite=$_POST['Komite'];
	$TA=$_POST['TA'];
	$OSIS=$_POST['OSIS'];
	$Prakerin=$_POST['Prakerin'];
	$DPS=$_POST['DPS'];
	$Iuran=$_POST['Iuran'];
	$PemasukanLain=$_POST['PemasukanLain'];
	$Pengembalian=$_POST['Pengembalian'];
	$totalMasuk=$_POST['totalMasuk'];
	$setoranSPP=$_POST['setoranSPP'];
	$setoranTA=$_POST['setoranTA'];
	$setoranOSIS=$_POST['setoranOSIS'];
	$setoranPrakerin=$_POST['setoranPrakerin'];
	$setoranDPS=$_POST['setoranDPS'];
	$totalSetoran=$_POST['totalSetoran'];
	$pinjaman=$_POST['pinjaman'];
	$other=$_POST['other'];
	$totalKeluar=$_POST['totalKeluar'];
	$saldo=$_POST['saldo'];
	
	$pdf=new FPDF();
	$pdf->AddPage();
	$pdf->SetLeftMargin(20);
	
	$pdf->SetFont('times','B',14);
	$pdf->Cell(40,10,'Laporan Harian',0,0,'C');
	$pdf->Cell(80,10,'',0,0,'C');
	$pdf->Cell(10,7,$tanggal,1,0,'C');
	$pdf->Cell(26,7,$bulan,1,0,'C');
	$pdf->Cell(14,7,$tahun,1,1,'C');
	$pdf->Cell(160,10,'',0,1,'C');
	
	$pdf->SetFont('times','',12);
	$pdf->Cell(48,10,'Pemasukan Iuran Komite',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$Komite,0,1,'L');
	
	$pdf->Cell(48,10,'Pemasukan Dana TA',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$TA,0,1,'L');
	
	$pdf->Cell(48,10,'Pemasukan Iuran OSIS',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$OSIS,0,1,'L');
	
	$pdf->Cell(48,10,'Pemasukan Iuran Prakerin',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$Prakerin,0,1,'L');
	
	$pdf->Cell(48,10,'Pemasukan Iuran DPS',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$DPS,0,1,'L');
	
	$pdf->Cell(50,10,'--------------------------------------------------------------------------------------------------',0,1,'L');
	
	$pdf->Cell(80,10,'Total Pemasukan Iuran',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$totalSetoran,0,1,'L');
	
	$pdf->Cell(80,10,'Pemasukan Lain',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$PemasukanLain,0,1,'L');
	
	$pdf->Cell(80,10,'Pengembalian Bon',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$Pengembalian,0,1,'L');

	$pdf->SetFont('times','B',12);
	$pdf->Cell(80,10,'Total Pemasukan',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$totalMasuk,0,1,'L');
	
	$pdf->Cell(160,10,'',0,1,'C');
	
	$pdf->SetFont('times','',12);
	$pdf->Cell(48,10,'Setoran Iuran Komite',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$setoranKomite,0,1,'L');
	
	$pdf->Cell(48,10,'Setoran Dana TA',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$setoranTA,0,1,'L');
	
	$pdf->Cell(48,10,'Setoran Iuran OSIS',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$setoranOSIS,0,1,'L');
	
	$pdf->Cell(48,10,'Setoran Iuran Prakerin',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$setoranPrakerin,0,1,'L');
	
	$pdf->Cell(48,10,'Setoran Iuran DPS',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$setoranDPS,0,1,'L');
	
	$pdf->Cell(50,10,'--------------------------------------------------------------------------------------------------',0,1,'L');

	$pdf->Cell(80,10,'Total Setoran',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$Iuran,0,1,'L');

	$pdf->Cell(80,10,'Pengeluaran Lain',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$other,0,1,'L');
	
	$pdf->Cell(80,10,'Peminjaman / Bon',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$pinjaman,0,1,'L');
	
	$pdf->SetFont('times','B',12);
	$pdf->Cell(80,10,'Total Pengeluaran',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$totalKeluar,0,1,'L');
	
	$pdf->Cell(160,10,'',0,1,'C');
	
	$pdf->Cell(80,10,'Total Uang Tersisa',0,0,'L');
	$pdf->Cell(2,10,':',0,0,'L');
	$pdf->Cell(20,10,$saldo,0,1,'L');
	
	
	
	$pdf->Output();
?>