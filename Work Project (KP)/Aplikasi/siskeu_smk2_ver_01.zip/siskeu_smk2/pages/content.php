<?
	session_start();
	
	if(isset($_SESSION['user'])){
		$user=$_SESSION['user'];
		$grup=$_SESSION['grup'];
		
		include("../dbase.php");
	
		$sheet=$_GET['sheet'];
		
		if(empty($sheet)){
			$sheet='sheet-default/default';
		}
		
		if(ereg('^[a-z0-9/-]+$',$sheet)){
			if($_GET['err']){
		?>
			<script language='javascript'>
				alert("<?echo $_GET['err']?>");
			</script>
		<?
			}
			include("sheets/{$sheet}.php");
		} else {
			
		}
	}
?>