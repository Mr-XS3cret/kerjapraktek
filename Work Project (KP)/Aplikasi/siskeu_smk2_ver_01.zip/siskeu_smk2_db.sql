/*
SQLyog Community Edition- MySQL GUI v8.05 
MySQL - 5.1.35-community : Database - mykp_dbs
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`mykp_dbs` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mykp_dbs`;

/*Table structure for table `pub_grupmember` */

DROP TABLE IF EXISTS `pub_grupmember`;

CREATE TABLE `pub_grupmember` (
  `idGrup` int(11) NOT NULL AUTO_INCREMENT,
  `namaGrup` varchar(45) NOT NULL,
  `levelGrup` int(11) DEFAULT NULL,
  PRIMARY KEY (`idGrup`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `pub_grupmember` */

insert  into `pub_grupmember`(`idGrup`,`namaGrup`,`levelGrup`) values (1,'Aadministrator',1),(2,'Kepala Sekolah',2),(3,'Guru',3),(4,'siswa',4);

/*Table structure for table `pub_member` */

DROP TABLE IF EXISTS `pub_member`;

CREATE TABLE `pub_member` (
  `idMember` int(11) NOT NULL AUTO_INCREMENT,
  `namaMember` varchar(45) NOT NULL,
  `passwordMember` varchar(45) NOT NULL,
  `grupMember` int(11) NOT NULL,
  PRIMARY KEY (`idMember`),
  KEY `grup` (`grupMember`),
  CONSTRAINT `grup` FOREIGN KEY (`grupMember`) REFERENCES `pub_grupmember` (`idGrup`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `pub_member` */

insert  into `pub_member`(`idMember`,`namaMember`,`passwordMember`,`grupMember`) values (1,'Adi','adi',1),(2,'Rudi','rudi',2);

/*Table structure for table `pub_menu` */

DROP TABLE IF EXISTS `pub_menu`;

CREATE TABLE `pub_menu` (
  `idMenu` int(11) DEFAULT NULL,
  `namaMenu` varchar(16) DEFAULT NULL,
  `accesLevel` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `pub_menu` */

insert  into `pub_menu`(`idMenu`,`namaMenu`,`accesLevel`) values (1,'Input Data',1),(2,'Rekapitulasi',4),(3,'Edit',1),(0,'Search',4),(4,'Fitur',2);

/*Table structure for table `pub_sheet` */

DROP TABLE IF EXISTS `pub_sheet`;

CREATE TABLE `pub_sheet` (
  `idSheet` int(11) NOT NULL AUTO_INCREMENT,
  `namaSheet` varchar(45) NOT NULL,
  `pageSheet` varchar(45) NOT NULL,
  `levelSheet` int(11) NOT NULL,
  `idMenu` int(11) DEFAULT NULL,
  PRIMARY KEY (`idSheet`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `pub_sheet` */

insert  into `pub_sheet`(`idSheet`,`namaSheet`,`pageSheet`,`levelSheet`,`idMenu`) values (1,'Iuran Siswa','input',1,1),(2,'Rekap Iuran Siswa','rekap-iuran',4,2),(3,'Pemasukan Lain','input-lain',1,1),(4,'Rekap&nbsp;Pemasukan','rekap-lain',4,2),(5,'Penyetoran','setoran',1,1),(6,'Rekap&nbsp;Peminjaman','rekap-bon',1,2),(7,'Peminjaman','input-bon',1,1),(8,'Rekap Pengeluaran','rekap-out',4,2),(9,'Pengeluaran Lain','outcome',2,1),(11,'Rekap Umum Harian','lapor',4,2),(12,'Edit & Tambah Data','edit',1,3),(13,'Detail Siswa','search',4,0),(14,'Ujian','ujian',2,4);

/*Table structure for table `pub_subsheet` */

DROP TABLE IF EXISTS `pub_subsheet`;

CREATE TABLE `pub_subsheet` (
  `idSubSheet` int(11) NOT NULL AUTO_INCREMENT,
  `namaSubSheet` varchar(45) NOT NULL,
  `idSheet` int(11) NOT NULL,
  `levelSubSheet` int(11) NOT NULL,
  PRIMARY KEY (`idSubSheet`),
  KEY `parentSheet` (`idSheet`),
  CONSTRAINT `parentSheet` FOREIGN KEY (`idSheet`) REFERENCES `pub_sheet` (`idSheet`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Data for the table `pub_subsheet` */

insert  into `pub_subsheet`(`idSubSheet`,`namaSubSheet`,`idSheet`,`levelSubSheet`) values (1,'Rekap Komite',2,2),(2,'Rekap TA',2,2),(3,'Rekap OSIS',2,2),(4,'Rekap Prakerin',2,2),(5,'Rekap DPS',2,2),(6,'Rekap Harian',2,2),(7,'Pemasukan Tetap',4,4),(8,'Pemasukan&nbsp;Lain-lain',4,4),(9,'Rekap Harian',4,2),(10,'Rekap Harian',6,2),(11,'Rekap Harian',8,2),(12,'Tambah Siswa',12,1),(13,'Edit Siswa',12,1),(14,'Edit Iuran',12,1),(15,'Cetak Kartu ',14,1),(16,'Ujian&nbsp;Tengah&nbsp;Semester',14,2),(17,'Ujian&nbsp;Akhir&nbsp;Semester',14,2);

/*Table structure for table `sis_change` */

DROP TABLE IF EXISTS `sis_change`;

CREATE TABLE `sis_change` (
  `idChange` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalChange` datetime NOT NULL,
  `nisSiswaChange` varchar(16) NOT NULL,
  `nominalChange` int(11) NOT NULL,
  PRIMARY KEY (`idChange`),
  KEY `FK_nis_Change` (`nisSiswaChange`),
  CONSTRAINT `FK_nis_Change` FOREIGN KEY (`nisSiswaChange`) REFERENCES `sis_siswa` (`nisSiswa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_change` */

insert  into `sis_change`(`idChange`,`tanggalChange`,`nisSiswaChange`,`nominalChange`) values (1,'2009-08-04 21:07:54','14765',630000),(2,'2009-08-04 08:08:42','14766',50000),(3,'2009-08-05 21:21:29','14766',50000),(4,'2009-08-05 21:22:09','14773',100000),(5,'2009-08-05 21:26:48','14766',50000);

/*Table structure for table `sis_historypemasukan` */

DROP TABLE IF EXISTS `sis_historypemasukan`;

CREATE TABLE `sis_historypemasukan` (
  `idHistory` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalMasuk` date NOT NULL,
  `idNamaPemasukan` int(11) NOT NULL,
  `nominalPemasukan` int(11) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idHistory`),
  KEY `FK_sis_historyPemasukan` (`idNamaPemasukan`),
  CONSTRAINT `FK_sis_historyPemasukan` FOREIGN KEY (`idNamaPemasukan`) REFERENCES `sis_pemasukanlain` (`idPemasukan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_historypemasukan` */

insert  into `sis_historypemasukan`(`idHistory`,`tanggalMasuk`,`idNamaPemasukan`,`nominalPemasukan`,`keterangan`) values (1,'2009-07-27',4,10000000,'Penyewaan gedung serba guna selama 2 hari'),(2,'2009-07-27',3,1500000,''),(3,'2009-07-29',3,3000000,''),(4,'2009-07-27',4,400000,'Penyewaan Lapangan tenis'),(5,'2009-07-29',2,5000000,''),(6,'2009-07-29',5,25000000,''),(7,'2009-08-02',1,1000000,''),(8,'2009-08-04',5,5000000,'');

/*Table structure for table `sis_kategoriiuran` */

DROP TABLE IF EXISTS `sis_kategoriiuran`;

CREATE TABLE `sis_kategoriiuran` (
  `idKategoriIuran` int(11) NOT NULL AUTO_INCREMENT,
  `idIuran` int(11) NOT NULL,
  `jenjangKelasIuran` int(11) NOT NULL,
  `nominalIuran` int(11) NOT NULL,
  PRIMARY KEY (`idKategoriIuran`),
  KEY `FK_jenjang_kategoriIuran` (`jenjangKelasIuran`),
  KEY `FK_sis_kategoriIuran` (`idIuran`),
  CONSTRAINT `FK_sis_kategoriIuran` FOREIGN KEY (`idIuran`) REFERENCES `sis_namaiuran` (`idNamaIuran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_kategoriiuran` */

insert  into `sis_kategoriiuran`(`idKategoriIuran`,`idIuran`,`jenjangKelasIuran`,`nominalIuran`) values (1,1,1,125000),(2,2,0,25000),(3,3,0,70000),(4,4,0,50000),(5,5,0,-2),(6,1,2,100000),(7,1,3,75000);

/*Table structure for table `sis_kelas` */

DROP TABLE IF EXISTS `sis_kelas`;

CREATE TABLE `sis_kelas` (
  `idKelas` int(11) NOT NULL AUTO_INCREMENT,
  `namaKelas` varchar(32) NOT NULL,
  PRIMARY KEY (`idKelas`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_kelas` */

insert  into `sis_kelas`(`idKelas`,`namaKelas`) values (1,'Akuntansi A'),(2,'TeKaJe'),(3,'Penjualan'),(4,'Restoran'),(5,'Tata Busana'),(6,'Akuntansi B');

/*Table structure for table `sis_namaiuran` */

DROP TABLE IF EXISTS `sis_namaiuran`;

CREATE TABLE `sis_namaiuran` (
  `idNamaIuran` int(11) NOT NULL AUTO_INCREMENT,
  `namaIuran` varchar(32) NOT NULL,
  `onRelation` int(11) NOT NULL,
  `onTempo` tinyint(1) NOT NULL,
  `notGeneral` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idNamaIuran`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_namaiuran` */

insert  into `sis_namaiuran`(`idNamaIuran`,`namaIuran`,`onRelation`,`onTempo`,`notGeneral`) values (1,'Dana Komite',1,1,1),(2,'Dana TA',2,1,0),(3,'Dana Kesiswaan (OSIS)',4,0,0),(4,'Dana Prakerin',3,0,0),(5,'Dana Pengembangan Sekolah',5,0,1);

/*Table structure for table `sis_pemasukanlain` */

DROP TABLE IF EXISTS `sis_pemasukanlain`;

CREATE TABLE `sis_pemasukanlain` (
  `idPemasukan` int(11) NOT NULL AUTO_INCREMENT,
  `namaPemasukan` varchar(64) NOT NULL,
  `totalPemasukan` int(11) NOT NULL,
  PRIMARY KEY (`idPemasukan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_pemasukanlain` */

insert  into `sis_pemasukanlain`(`idPemasukan`,`namaPemasukan`,`totalPemasukan`) values (1,'Dana BOS',26000000),(2,'Bantuan APBN',7000000),(3,'Bantuan APBD',3000000),(4,'Lain-Lain',1150000),(5,'Dana Sponsor',5000000);

/*Table structure for table `sis_peminjaman` */

DROP TABLE IF EXISTS `sis_peminjaman`;

CREATE TABLE `sis_peminjaman` (
  `idPeminjaman` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalPeminjaman` date NOT NULL,
  `namaPeminjam` varchar(64) NOT NULL,
  `nominalPeminjaman` int(11) NOT NULL,
  `statusPinjaman` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idPeminjaman`)
) ENGINE=InnoDB AUTO_INCREMENT=2011 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_peminjaman` */

insert  into `sis_peminjaman`(`idPeminjaman`,`tanggalPeminjaman`,`namaPeminjam`,`nominalPeminjaman`,`statusPinjaman`) values (1,'2009-07-30','Drs Kamal Abdullah',500000,0),(2,'2009-07-30','Malik',200000,0),(3,'2009-07-30','Ardian',300000,0),(2010,'2009-08-04','Ardian',100000,0);

/*Table structure for table `sis_pengeluaranlain` */

DROP TABLE IF EXISTS `sis_pengeluaranlain`;

CREATE TABLE `sis_pengeluaranlain` (
  `idPengeluaranLain` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalPengeluaranLain` date NOT NULL,
  `nominalPengeluaranLain` int(11) NOT NULL,
  `pjPengeluaranLain` varchar(64) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`idPengeluaranLain`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_pengeluaranlain` */

insert  into `sis_pengeluaranlain`(`idPengeluaranLain`,`tanggalPengeluaranLain`,`nominalPengeluaranLain`,`pjPengeluaranLain`,`keterangan`) values (1,'2009-07-30',150000,'Erik','Beli Alat Kebersihan'),(2,'2009-07-30',200000,'Hatono','Membeli Alat Kebersihan untuk kelas-kelas');

/*Table structure for table `sis_pengembalian` */

DROP TABLE IF EXISTS `sis_pengembalian`;

CREATE TABLE `sis_pengembalian` (
  `idKembali` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalKembali` date NOT NULL,
  `namaPengembali` varchar(64) NOT NULL,
  `nominalKembali` int(11) NOT NULL,
  PRIMARY KEY (`idKembali`)
) ENGINE=InnoDB AUTO_INCREMENT=2010 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_pengembalian` */

insert  into `sis_pengembalian`(`idKembali`,`tanggalKembali`,`namaPengembali`,`nominalKembali`) values (1,'2009-07-30','Malik',200000),(2,'2009-07-30','Ardian',300000),(3,'2009-07-31','Drs Kamal Abdullah',500000),(2009,'0000-00-00','500000',0);

/*Table structure for table `sis_rekapiuransiswa` */

DROP TABLE IF EXISTS `sis_rekapiuransiswa`;

CREATE TABLE `sis_rekapiuransiswa` (
  `idRekap` int(11) NOT NULL AUTO_INCREMENT,
  `nisSiswaRekap` varchar(16) NOT NULL,
  `idnamaIuranRekap` int(11) NOT NULL,
  `nominalRekap` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idRekap`),
  KEY `FK_nis_RekapIuranSiswa` (`nisSiswaRekap`),
  KEY `FK_namaiuran_RekapIuranSiswa` (`idnamaIuranRekap`),
  CONSTRAINT `FK_namaiuran_RekapIuranSiswa` FOREIGN KEY (`idnamaIuranRekap`) REFERENCES `sis_namaiuran` (`idNamaIuran`) ON UPDATE CASCADE,
  CONSTRAINT `FK_nis_RekapIuranSiswa` FOREIGN KEY (`nisSiswaRekap`) REFERENCES `sis_siswa` (`nisSiswa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_rekapiuransiswa` */

insert  into `sis_rekapiuransiswa`(`idRekap`,`nisSiswaRekap`,`idnamaIuranRekap`,`nominalRekap`) values (1,'14765',1,200000),(2,'14765',2,50000),(3,'14765',3,70000),(4,'14765',4,50000),(5,'14765',5,0),(6,'14766',1,750000),(7,'14766',2,0),(8,'14766',3,0),(9,'14766',4,0),(10,'14766',5,0),(11,'14769',1,0),(12,'14769',2,0),(13,'14769',3,0),(14,'14769',4,0),(15,'14769',5,0),(16,'14767',1,0),(17,'14767',2,0),(18,'14767',3,0),(19,'14767',4,0),(20,'14767',5,0),(21,'14768',1,0),(22,'14768',2,0),(23,'14768',3,0),(24,'14768',4,0),(25,'14768',5,0),(26,'14770',1,0),(27,'14770',2,0),(28,'14770',3,0),(29,'14770',4,0),(30,'14770',5,0),(31,'14771',1,0),(32,'14771',2,0),(33,'14771',3,0),(34,'14771',4,0),(35,'14771',5,0),(36,'14772',1,0),(37,'14772',2,0),(38,'14772',3,0),(39,'14772',4,0),(40,'14772',5,0),(41,'14773',1,0),(42,'14773',2,0),(43,'14773',3,0),(44,'14773',4,0),(45,'14773',5,0);

/*Table structure for table `sis_setoran` */

DROP TABLE IF EXISTS `sis_setoran`;

CREATE TABLE `sis_setoran` (
  `idSetoran` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalSetoran` date NOT NULL,
  `idNamaSetoran` int(11) NOT NULL,
  `nominalSetoran` int(11) NOT NULL,
  PRIMARY KEY (`idSetoran`),
  KEY `FK_jenis_Setoran` (`idNamaSetoran`),
  CONSTRAINT `FK_jenis_Setoran` FOREIGN KEY (`idNamaSetoran`) REFERENCES `sis_namaiuran` (`idNamaIuran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_setoran` */

insert  into `sis_setoran`(`idSetoran`,`tanggalSetoran`,`idNamaSetoran`,`nominalSetoran`) values (1,'2009-08-06',1,200000);

/*Table structure for table `sis_siswa` */

DROP TABLE IF EXISTS `sis_siswa`;

CREATE TABLE `sis_siswa` (
  `nisSiswa` varchar(16) NOT NULL,
  `namaSiswa` varchar(45) NOT NULL,
  `jenjangKelas` int(11) NOT NULL,
  `idKelasSiswa` int(11) NOT NULL,
  `passwordSiswa` varchar(45) NOT NULL DEFAULT '0',
  `nominalDPS` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nisSiswa`),
  KEY `FK_sis_Siswa` (`idKelasSiswa`),
  CONSTRAINT `FK_sis_Siswa` FOREIGN KEY (`idKelasSiswa`) REFERENCES `sis_kelas` (`idKelas`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `sis_siswa` */

insert  into `sis_siswa`(`nisSiswa`,`namaSiswa`,`jenjangKelas`,`idKelasSiswa`,`passwordSiswa`,`nominalDPS`) values ('14765','Muhammad Ardianto',2,1,'14765',2000000),('14766','Ardi Helmi',1,1,'14766',1000000),('14767','Ardiantsari',1,6,'14767',1500000),('14768','Ardiansyah',1,1,'14768',1000000),('14769','Ardidoang',1,1,'14769',1500000),('14770','Ardianduk',1,1,'14770',1000000),('14771','Muhtarom',1,1,'14771',2000000),('14772','Harjo Sukirno',1,1,'14772',1500000),('14773','Aditya Wardani',1,3,'14773',1500000);

/*Table structure for table `sis_transaksi` */

DROP TABLE IF EXISTS `sis_transaksi`;

CREATE TABLE `sis_transaksi` (
  `idTransaksi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalTransaksi` date NOT NULL,
  `nisSiswaTransaksi` varchar(16) NOT NULL,
  `idKategoriIuranTrans` int(11) NOT NULL,
  `nominalTransaksi` int(11) NOT NULL,
  PRIMARY KEY (`idTransaksi`),
  KEY `FK_siswa_Transaksi` (`nisSiswaTransaksi`),
  KEY `FK_sisidKategori_Transaksi` (`idKategoriIuranTrans`),
  CONSTRAINT `FK_sisidKategori_Transaksi` FOREIGN KEY (`idKategoriIuranTrans`) REFERENCES `sis_kategoriiuran` (`idKategoriIuran`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_siswa_Transaksi` FOREIGN KEY (`nisSiswaTransaksi`) REFERENCES `sis_siswa` (`nisSiswa`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sis_transaksi` */

insert  into `sis_transaksi`(`idTransaksi`,`tanggalTransaksi`,`nisSiswaTransaksi`,`idKategoriIuranTrans`,`nominalTransaksi`) values (33,'2009-08-05','14765',1,200000),(34,'2009-08-05','14765',2,50000),(35,'2009-08-05','14765',3,70000),(36,'2009-08-05','14765',4,50000),(37,'2009-08-05','14765',5,0),(38,'2009-08-05','14766',1,0),(39,'2009-08-05','14766',2,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
